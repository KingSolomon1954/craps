//----------------------------------------------------------------
//
// File: Dice.h
//
//----------------------------------------------------------------

#pragma once

#include <string>

namespace Craps {

class Dice
{
public:
    /// @name Lifecycle
    /// @{
    Dice() = default;
   ~Dice() = default;
    /// @}

    /// @name Modifiers
    /// @{
    unsigned roll();
    void set(unsigned d1, unsigned d2);  // Primarily for testing
    /// @}

    /// @name Observers
    /// @{
    unsigned value()             const;
    unsigned d1()                const;
    unsigned d2()                const;
    unsigned rollCount()         const;
    std::string toString()       const;
    bool operator==(const Dice&) const = default;  // Only generates ==
    /// @}

private:
    int getRandomNumber(int min, int max) const;
    
    unsigned d1_ = 6; 
    unsigned d2_ = 6;
    unsigned rollCount_ = 0;
};

/*-----------------------------------------------------------*//**

@class Dice

@brief Dice

Two die.

*/

} // namespace Craps

//----------------------------------------------------------------
