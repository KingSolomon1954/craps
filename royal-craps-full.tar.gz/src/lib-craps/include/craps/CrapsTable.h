//----------------------------------------------------------------
//
// File: CrapsTable.h
//
//----------------------------------------------------------------

#pragma once

#include <craps/Bank.h>
#include <craps/CrapsBet.h>
#include <craps/CrapsTypes.h>
#include <craps/DecisionRecord.h>
#include <craps/Dice.h>
#include <craps/LastRollStats.h>
#include <craps/TableConfig.h>
#include <craps/TableRules.h>
#include <craps/TableStats.h>
#include <gen/Debug.h>
#include <gen/ErrorPass.h>
#include <gen/MoneyUtils.h>
#include <gen/ReturnCode.h>
#include <gen/Timepoint.h>
#include <yaml-cpp/yaml.h>
#include <zeus/expected.hpp>
#include <array>
#include <list>

namespace Craps {

class Player;  // fwd

class CrapsTable
{
public:
    /// @name Lifecycle
    /// @{
    CrapsTable(const TableId&     tableId,
               const TableConfig& config);

   ~CrapsTable() = default;
    void shutdown();
    static CrapsTable* fromString(std::string        yaml,
                                  const TableId&     tableId,
                                  const TableConfig& config);
    /// @}

    /// @name Modifiers
    /// @{
    // Players
    zeus::expected<void, Gen::ErrorPass> addPlayer   (Player& player);
    zeus::expected<void, Gen::ErrorPass> removePlayer(Player& player);
    zeus::expected<void, Gen::ErrorPass> replacePlayer(Player& leaving,
                                                       Player& joining);
    void setShooter(Player& pPlayer);

    // Bets
    Gen::ReturnCode addBet        (BetPtr pBet, Gen::ErrorPass& ep);
    Gen::ReturnCode removeBet     (BetPtr pBet, Gen::ErrorPass& ep);
    void            removeBetForce(BetPtr pBet);
    Gen::ReturnCode setContractAmount(BetPtr pBet,
                                      Gen::Money newAmount,
                                      Gen::ErrorPass& ep);
    Gen::ReturnCode setOddsAmount(BetPtr pBet,
                                  Gen::Money oddsAmount,
                                  Gen::ErrorPass& ep);

    // Table
    void rollDice();
    void resetStats();
    void close();               // Shutdown table, switching to different table
    /// @}

    /// @name Observers
    /// @{
    unsigned                getNumPlayers()             const;
    unsigned                getPoint()                  const;
    Dice                    getCurrentRoll()            const;
    unsigned                getNumRolls()               const;
    Gen::Money              getAmountOnTable()          const;
    unsigned                getNumBetsOnTable()         const;
    std::vector<Player*>    getPlayers()                const;
    Player*                 getCurrentShooter()         const;
    const TableId&          getTableId()                const;
    const std::string&      getTableName()              const;
    const RecentRolls&      getRecentRolls()            const;
    const TableStats&       getCurrentStats()           const;
    const TableStats&       getAlltimeStats()           const;
    const BankStats&        getBankCurrentStats()       const;
    const BankStats&        getBankAlltimeStats()       const;
    const LastRollStats&    getLastRollStats()          const;
    int                     getBalance()                const;
    unsigned                getMinLineBet()             const;
    unsigned                getMaxLineBet()             const;
    unsigned                getMaxOdds()                const;
    const TableRules&       getTableRules()             const;
    BetAmountLimits          getBetAmountLimits(BetName betName,
                                                unsigned pivot,
                                                bool oddsBet,
                                                Gen::Money contractAmount) const;
    BetPtr                  getBet (const BetId& betId, Gen::ErrorPass& ep) const;
    bool                    haveBet(const BetId& betId) const;
    bool                    isComeOutRoll()             const;
    bool                    isBettingOpen()             const;
    bool                    isBetRemovable(BetPtr pBet) const;
    bool                    havePlayer(const Player* pPlayer)            const;
    bool                    isBetAllowed(BetName name, std::string& str) const;
    const SessionHistory::Sessions& getSessionHistory()                  const;
    /// @}

    /// @name YAML conversion
    /// The table's own state. Knows nothing about files; TableManager
    /// owns the file and decides when to read and write it.
    /// @{
    YAML::Node toYAML() const;
    void fromYAML(const YAML::Node& node);   // throws
    /// @}

    // Unit test access points
#ifdef UNIT_TEST
public:
    void testRollDice(unsigned d1, unsigned d2)
    {
        isTestRoll_ = true;
        testRollDice_.set(d1, d2);
        rollDice();
    };
    void testSetState(unsigned point, unsigned d1, unsigned d2)
    {
        point_ = point;
        dice_.set(d1, d2);
    }
#endif

private:
    // order matters
    TableId tableId_;  // Table-1, Table-2, ...
    TableConfig config_;
    Bank houseBank_;   // overriden by yaml

    // order doesn't matter
    std::string tableName_;
    std::string shortDescription_;
    std::string fullDescription_;
    Dice dice_;
    unsigned point_ = 0;
    Player* pCurrentShooter_ = nullptr;
    bool bettingOpen_ = true;
    bool isTestRoll_ = false;
    Dice testRollDice_;
    TableStats currentStats_;
    TableStats alltimeStats_;
    LastRollStats lastRollStats_;
    RecentRolls recentRolls_;  // Front element is oldest roll

    TableRules rules_;

    CrapsTable();  // private ctor

    // Players must join table in order to play.
    static inline constexpr size_t MaxPlayers = 6;
    using PlayerList = std::list<Player*>;
    PlayerList players_;

    // Bets on the table are kept in a fixed sized array of lists, where
    // each array index equates to a bet type, and holds a list of bets
    // of that type. This allows easier traversals later that mimic real
    // life table actions where, for example, the house always first
    // collects losing bets in a certain order followed by payouts of
    // winning bets in a certain order.
    //
    using BetList = std::list<BetPtr>;
    using BetTable = std::array<BetList, EnumBetName::enumerators.size()>;
    BetTable tableBets_;

    // After each dice roll, a decision list is populated with the
    // the results of all bets on the table, one entry for each bet.
    using DecisionList = std::list<DecisionRecord>;
    DecisionList drl_;

private:
    friend class Player;

    Gen::Money placementCommission(const CrapsBet& bet, Gen::Money contractAmount) const;
    void collectPlacementCommission(CrapsBet& bet, Gen::Money amount);
    void refundPlacementCommission(CrapsBet& bet);

    bool betAllowed(CrapsBet& bet, Gen::ErrorPass& ep) const;
    void throwDice();
    bool resolveBets();
    void advanceState();
    void advanceShooter();
    void bumpRecentRolls(const Dice& dice);
    bool evaluateBets();
    void dispenseResults();
    void trimTableBets();
    void clearDrl();
    bool evalOneBet(CrapsBet& bet);

    void declareBettingClosed();
    void declareBettingOpen();
    void disburseDone();

    void removePlayerByPtr    (Player* pPlayer);
    void removePlayerBets     (Player* pPlayer);
    void removeBetsByPlayerPtr(BetList& bets, Player* pPlayer);
    bool removeMatchingBet    (BetList& bets, CrapsBet* pBet);
    BetPtr findBetById        (const BetId& betId) const;

    void disburseHouseResults();
    void disbursePlayerWins();
    void disbursePlayerLoses();
    void disbursePlayerKeeps();

    void sendEventPlayerJoinedTable(const Player& player) const;
    void sendEventPlayerLeftTable  (const Player& player) const;
    void sendEventBetMade          (const CrapsBet& bet)  const;
    void sendEventBetRemoved       (const CrapsBet& bet)  const;
    void sendEventBetChanged       (const CrapsBet& bet)  const;
    void sendEventDiceThrowStart()                        const;
    void sendEventDiceNewValue()                          const;
    void sendEventTableResolveBetsEnd()                   const;
    void sendEventTableLastRollStatsChanged()             const;
    void sendEventTableSessionStatsChanged()              const;
    void sendEventTableBetsChanged()                      const;
    void sendEventTableBalanceChanged()                   const;
    void sendEventBetEvaluationFailed(const CrapsBet& bet,
                                 const std::string& diag) const;

    // YAML conversion of the rules, used by toYAML() and fromYAML()
    YAML::Node rulesToYAML() const;
    void rulesFromYAML(const YAML::Node& node);

    // Validity checks with diagnostics, in CrapsTablePart2.cpp
    std::string diagPrefix    (size_t idx, const CrapsBet& bet) const;
    std::string diagLimits(Gen::Money amt) const;
    bool fifBettingClosed     (const CrapsBet& bet, size_t idx, Gen::ErrorPass& ep)                 const;
    bool fifMissingPlayer     (const CrapsBet& bet,  Gen::ErrorPass& ep)                            const;
    bool fifHavePlayer        (const Player& player, Gen::ErrorPass& ep)                            const;
    bool fifMaxPlayers        (Gen::ErrorPass& ep)                                                  const;
    bool fifBetPtrNull        (const BetPtr pBet, const std::string& fName, Gen::ErrorPass& ep)     const;
    bool fifMissingBet        (const CrapsBet& bet, size_t idx, Gen::ErrorPass& ep)                 const;
    bool fifHaveBet           (const CrapsBet& bet, Gen::ErrorPass& ep)                             const;                
    bool fifComeDisallowed    (const CrapsBet& bet, Gen::ErrorPass& ep)                             const;
    bool fifDontPassDisallowed(const CrapsBet& bet, Gen::ErrorPass& ep)                             const;
    bool fifBetMustRemain     (BetPtr pBet,         Gen::ErrorPass& ep)                             const;
    bool fifBadBetTypeForOdds (const CrapsBet& bet, Gen::ErrorPass& ep)                             const;
    bool fifZeroPivotForOdds  (const CrapsBet& bet, Gen::ErrorPass& ep)                             const;
    bool fifBadMinMaxLineBets (const CrapsBet& bet, Gen::Money amt, size_t idx, Gen::ErrorPass& ep) const;
    bool fifBadMinMaxSideBets (const CrapsBet& bet, Gen::Money amt, size_t idx, Gen::ErrorPass& ep) const;
    bool fifZeroAmount        (const CrapsBet& bet, Gen::Money amt, size_t idx, Gen::ErrorPass& ep) const;
    bool fifBadPassLineChange (const CrapsBet& bet, Gen::Money amt, size_t idx, Gen::ErrorPass& ep) const;
    bool fifBadDontPassChange (const CrapsBet& bet, Gen::Money amt, size_t idx, Gen::ErrorPass& ep) const;
    bool fifBadMultiples      (const CrapsBet& bet, Gen::Money amt, size_t idx, Gen::ErrorPass& ep) const;
    bool fifBadMinMaxForOdds  (const CrapsBet& bet, Gen::Money amt, Gen::ErrorPass& ep)             const;
    bool withinMinMaxLineBets (BetName betName, Gen::Money contractAmount, Gen::ErrorPass& ep)      const;
    bool withinMinMaxSideBets (BetName betName, Gen::Money contractAmount, Gen::ErrorPass& ep)      const;
    bool goodMultiplesSideBets(BetName betName, Gen::Money amt, Gen::ErrorPass& ep)                 const;
    
    // Default bank constants for table
    static constexpr unsigned InitialStartingBankBalance_ = 3000000;
    static constexpr unsigned RefillThreshold_            = 1500000;
    static constexpr unsigned RefillAmount_               = 2000000;

    using En = Gen::ErrorPass::ErrorName;
    using Et = Gen::ErrorPass::ErrorType;
    using Es = Gen::ErrorPass::Severity;
};

/*-----------------------------------------------------------*//**

@class CrapsTable

@brief Craps Table.

Operates a Craps Table.

Responsibilities:

* interacts with players, bets, dice rolls, and house bank
* manages players and their bets
* accepts/rejects bets from players
* handles dice rolls and game phases
* processes dice rolls and bets
* gives win amounts to player
* processes payouts and bet resolutions
* removes wining/losing bets from table
* gives losing amounts to table bank
* refills table money from the casino bank
* controls who the shooter is
* passes dice to the shooter
* maintain stats on table play
* keeps track of the table state (point, current shooter, etc.)

*/

} // namespace Craps

//----------------------------------------------------------------
