//----------------------------------------------------------------
//
// File: CrapsBet.h
//
//----------------------------------------------------------------

#pragma once

#include <chrono>
#include <ostream>
#include <string>
#include <unordered_set>
#include <craps/CrapsTypes.h>
#include <craps/EnumBetName.h>
#include <craps/OddsTables.h>
#include <craps/TableRules.h>
#include <gen/MoneyUtils.h>
#include <gen/ReturnCode.h>
#include <gen/Timepoint.h>
#include <gen/Uuid.h>

namespace Gen {
    class ErrorPass;  // fwd
}

namespace Craps {

class Dice;            // fwd
class DecisionRecord;  // fwd
class Player;          // fwd
    
class CrapsBet
{
public:
    /// @name Lifecycle
    /// @{
    CrapsBet(Player*    pPlayer,
             BetName    name,
             Gen::Money contractAmount,
             unsigned   pivot = 0);
    /// @}

    /// @name Modifiers
    /// @{
    void setOffComeOutRoll();
    void setOnComeOutRoll();
    void setHardwayOff();
    void setHardwayOn();
    /// @}

    /// @name Observers
    /// @{
    Player&        player()          const;
    BetId          betId()           const;
    BetName        betName()         const;
    unsigned       pivot()           const;
    unsigned       contractAmount()  const;
    unsigned       oddsAmount()      const;
    Gen::Money     placementCommission() const; // Commission already collected on placement
    bool           hasDecision() const;           // A roll has resolved this bet at least once
    bool           offComeOutRoll()  const;
    bool           hardwayWorking()  const;
    unsigned       distance()        const;
    Gen::Timepoint whenCreated()     const;
    Gen::Timepoint whenDecided()     const;
    std::string    diagBetId()       const;  // "bet(betId:33, betName:DontCome(4))"
    bool operator==(const CrapsBet&) const;
    void           logBet(std::string_view intro) const;
    /// @}

private:
    // Order matters, in initializer list
    Player*    pPlayer_        = nullptr;
    BetId      betId_          = 0;
    BetName    betName_        = BetName::Invalid;
    unsigned   pivot_          = 0;
    Gen::Money contractAmount_ = 0;

    // Order doesn't matter
    Gen::Money oddsAmount_     = 0;
    Gen::Money placementCommission_ = 0; // retained after a winning Buy/Lay decision
    bool hasDecision_ = false;
    bool offComeOutRoll_       = true;
    unsigned distance_         = 0;  // num rolls until decision
    Gen::Timepoint whenCreated_;
    Gen::Timepoint whenDecided_;
    
    static unsigned idCounter_;
    static const std::unordered_set<unsigned> pointNums_;
    static const std::unordered_set<unsigned> fieldNums_;
    static const std::unordered_set<unsigned> crapsNums_;
    static const std::unordered_set<unsigned> bookEnds_;
    static const std::unordered_set<unsigned> hardwayNums_;

    enum Decision
    {
        Win,
        Lose,
        Keep
    };

    Gen::ReturnCode evaluate(unsigned point, const Dice& dice,
                             DecisionRecord& dr, Gen::ErrorPass& ep);
    Gen::ReturnCode evaluate(unsigned point, const Dice& dice,
                             const TableRules& rules,
                             DecisionRecord& dr, Gen::ErrorPass& ep);
    void checkBetName();
    void checkContractAmount();
    void checkLinePivot();
    void checkPlacePivot();
    void checkHardwayPivot();
    void checkSideBets();
    bool validArgsEval(unsigned point, Gen::ErrorPass& ep) const;
    Gen::ReturnCode evalPassLine(
        unsigned point, const Dice& dice, const TableRules& rules,
        DecisionRecord& dr, Gen::ErrorPass& ep);
    Gen::ReturnCode evalCome(
        unsigned point, const Dice& dice, const TableRules& rules,
        DecisionRecord& dr, Gen::ErrorPass& ep);
    Gen::ReturnCode evalDontPass(
        unsigned point, const Dice& dice, const TableRules& rules,
        DecisionRecord& dr, Gen::ErrorPass& ep);
    Gen::ReturnCode evalDontCome(
        unsigned point, const Dice& dice, const TableRules& rules,
        DecisionRecord& dr, Gen::ErrorPass& ep);
    Gen::ReturnCode evalPlace(
        unsigned point, const Dice& dice, const TableRules& rules,
        DecisionRecord& dr, Gen::ErrorPass& ep);
    Gen::ReturnCode evalLay(
        unsigned point, const Dice& dice, const TableRules& rules,
        DecisionRecord& dr, Gen::ErrorPass& ep);
    Gen::ReturnCode evalBuy(
        unsigned point, const Dice& dice, const TableRules& rules,
        DecisionRecord& dr, Gen::ErrorPass& ep);
    Gen::ReturnCode evalHardway(
        unsigned point, const Dice& dice,
        DecisionRecord& dr, Gen::ErrorPass& ep);
    Gen::ReturnCode evalField(
        unsigned point, const Dice& dice, const TableRules& rules,
        DecisionRecord& dr, Gen::ErrorPass& ep);
    Gen::ReturnCode evalAnyCraps(
        unsigned point, const Dice& dice,
        DecisionRecord& dr, Gen::ErrorPass& ep);
    Gen::ReturnCode evalAnySeven(
        unsigned point, const Dice& dice,
        DecisionRecord& dr, Gen::ErrorPass& ep);
    Gen::ReturnCode evalCandE(
        unsigned point, const Dice& dice,
        DecisionRecord& dr, Gen::ErrorPass& ep);
    Gen::ReturnCode evalHorn(
        unsigned point, const Dice& dice,
        DecisionRecord& dr, Gen::ErrorPass& ep);
    Gen::ReturnCode evalWorld(
        unsigned point, const Dice& dice,
        DecisionRecord& dr, Gen::ErrorPass& ep);
    void diagEvalEntered(unsigned point, const Dice& dice) const;
    Gen::ReturnCode diagEvalProcError(Gen::ErrorPass& ep) const;
    Gen::Money calculateOddsPayout(Gen::Money amount,
                                   unsigned numerator,
                                   unsigned denominator,
                                   TableRules::PayoutRounding rounding,
                                   Gen::Money payoutUnit) const;
    Gen::Money calculateCommission(Gen::Money grossWin,
                                   Gen::Money wager,
                                   const TableRules::Commission& rules) const;
    void calcWinPointBet(unsigned diceVal,
                         DecisionRecord& dr,
                         bool returnOdds,
                         const OddsTables::OddsEntry table[],
                         const TableRules& rules) const;
    void calcLossPointBet(DecisionRecord& dr, bool returnOdds) const;
    void setContractAmountInternal(Gen::Money amount); // called by CrapsTable
    void setOddsAmountInternal    (Gen::Money amount); // called by CrapsTable
    void setPlacementCommissionInternal(Gen::Money amount); // called by CrapsTable/Player
    void setPivotInternal         (unsigned pivot);    // called by CrapsTable
    void setDistanceInternal      (unsigned distance); // called by unit test

    friend class CrapsTable;
    friend class Player;
    friend class TableStats;

    // Unit test access points
#ifdef UNIT_TEST
public:
    void testSetContractAmount(Gen::Money amount)
    { setContractAmountInternal(amount); }
    void testSetOddsAmount(Gen::Money amount)
    { setOddsAmountInternal(amount); }
    void testSetPivot(unsigned pivot)
    { setPivotInternal(pivot); }
    void testSetDistance(unsigned distance)
    { setDistanceInternal(distance); }
    Gen::ReturnCode testEvaluate(unsigned point, const Dice& dice,
                                 DecisionRecord& dr, Gen::ErrorPass& ep)
    { return evaluate(point, dice, dr, ep); }
    Gen::ReturnCode testEvaluate(unsigned point, const Dice& dice,
                                 const TableRules& rules, DecisionRecord& dr,
                                 Gen::ErrorPass& ep)
    { return evaluate(point, dice, rules, dr, ep); }
#endif
    
};  // class CrapsBet

/*-----------------------------------------------------------*//**

@class CrapsBet

@brief A bet on the Craps table.

Manage a Craps bet on the table.

*/

} // namespace Craps

std::ostream& operator<< (std::ostream& out, const Craps::CrapsBet& b);
    
//----------------------------------------------------------------
