//----------------------------------------------------------------
//
// File: EnumBetName.cpp
//
//----------------------------------------------------------------

#include <craps/EnumBetName.h>
#include <gen/StringUtils.h>

using namespace EnumBetName;
using namespace Gen;

constexpr const char* PassLineStr = "PassLine";
constexpr const char* ComeStr     = "Come";
constexpr const char* DontPassStr = "DontPass";
constexpr const char* DontComeStr = "DontCome";
constexpr const char* PlaceStr    = "Place";
constexpr const char* LayStr      = "Lay";
constexpr const char* BuyStr      = "Buy";
constexpr const char* HardwayStr  = "Hardway";
constexpr const char* FieldStr    = "Field";
constexpr const char* AnyCrapsStr = "AnyCraps";
constexpr const char* AnySevenStr = "AnySeven";
constexpr const char* CandEStr    = "C&E";
constexpr const char* HornStr     = "Horn";
constexpr const char* WorldStr    = "World";
constexpr const char* InvalidStr  = "Invalid";

/*-----------------------------------------------------------*//**

Convert enum to string.

@param[in] b
    The enum of interest.

@return
    Enum as a string.
*/
std::string
EnumBetName::toString(BetName b) noexcept
{
    switch (b)
    {
    case BetName::PassLine: return PassLineStr;
    case BetName::Come:     return ComeStr;
    case BetName::DontPass: return DontPassStr;
    case BetName::DontCome: return DontComeStr;
    case BetName::Place:    return PlaceStr;
    case BetName::Lay:      return LayStr;
    case BetName::Buy:      return BuyStr;
    case BetName::Hardway:  return HardwayStr;
    case BetName::Field:    return FieldStr;
    case BetName::AnyCraps: return AnyCrapsStr;
    case BetName::AnySeven: return AnySevenStr;
    case BetName::CandE:    return CandEStr;
    case BetName::Horn:     return HornStr;
    case BetName::World:    return WorldStr;
    case BetName::Count:    // fall through
    case BetName::Invalid:  break; // quiet the compiler
    }
    return InvalidStr;
}

/*-----------------------------------------------------------*//**

Convert BetName string to enum.

@param[in] s
    The bet name as a string. Matching is not sensitive to case.
    Matches against these strings:
    "Invalid", "PassLine", "Come", "DontPass", "DontCome",
    "Place", "Lay", "Buy", "Hardway", "Field", "AnyCraps",
    "AnySeven", "C&E", "Horn", or "World".

@return
    Enum value.

@throws std::invalid_argument
    Throws for unrecognized strings. isConvertibleFrom()
    can be used if throw is not needed.
*/
BetName
EnumBetName::fromString(const std::string& s)
{
    for (auto val : enumerators)
    {
        if (StringUtils::insensitiveEquals(s, toString(val)))
        {
            return val;
        }
    }

    throw std::invalid_argument(
        "EnumBetName: Conversion error: "
        "Invalid conversion to enum: " +
        s +
        ", does not match any of " +
        listAsString());
}

/*-----------------------------------------------------------*//**

Returns a std::string of the enums separated by a space.

@return
    Returns a std::string of the enums separated by a space.
*/
std::string
EnumBetName::listAsString()
{
    std::string s;
    for (auto val : enumerators)
    {
        s += toString(val);
        s += " ";
    }
    StringUtils::trimEnd(s);
    return s;
}

/*-----------------------------------------------------------*//**

Determines if given string can convert to enum.

@param[in] s
    The string of interest.

@return
    True if convertible; false otherwise.
*/
bool
EnumBetName::isConvertibleFrom(const std::string& s) noexcept
{
    for (auto val : enumerators)
    {
        if (StringUtils::insensitiveEquals(s, toString(val)))
        {
            return true;
        }
    }
    return false;
}

/*-----------------------------------------------------------*//**

Convert to enum from size_t/unsigned integer.

@param[in] v
    Number to turn into an enum.

@return
    Enum value. Returns Invalid for an unrecognized conversion.
*/
BetName
EnumBetName::fromUnsigned(size_t v) noexcept
{
    if (v == static_cast<size_t>(BetName::PassLine))
    {
        return BetName::PassLine;
    }
    else if (v == static_cast<size_t>(BetName::Come))
    {
        return BetName::Come;
    }
    else if (v == static_cast<size_t>(BetName::DontPass))
    {
        return BetName::DontPass;
    }
    else if (v == static_cast<size_t>(BetName::DontCome))
    {
        return BetName::DontCome;
    }
    else if (v == static_cast<size_t>(BetName::Place))
    {
        return BetName::Place;
    }
    else if (v == static_cast<size_t>(BetName::Lay))
    {
        return BetName::Lay;
    }
    else if (v == static_cast<size_t>(BetName::Buy))
    {
        return BetName::Buy;
    }
    else if (v == static_cast<size_t>(BetName::Hardway))
    {
        return BetName::Hardway;
    }
    else if (v == static_cast<size_t>(BetName::Field))
    {
        return BetName::Field;
    }
    else if (v == static_cast<size_t>(BetName::AnyCraps))
    {
        return BetName::AnyCraps;
    }
    else if (v == static_cast<size_t>(BetName::AnySeven))
    {
        return BetName::AnySeven;
    }
    else if (v == static_cast<size_t>(BetName::CandE))
    {
        return BetName::CandE;
    }
    else if (v == static_cast<size_t>(BetName::Horn))
    {
        return BetName::Horn;
    }
    else if (v == static_cast<size_t>(BetName::World))
    {
        return BetName::World;
    }
    else
    {
        return BetName::Invalid;
    }
}

/*-----------------------------------------------------------*//**

Stream output operator for ::BetName.

@param[in,out] out
    The output stream.

@param[in] d
    The bet name enum.

@return
    The output stream.

@ingroup free
*/
std::ostream&
operator<< (std::ostream& out, const BetName& d)
{
    out << EnumBetName::toString(d);
    return out;
}

//-----------------------------------------------------------------
