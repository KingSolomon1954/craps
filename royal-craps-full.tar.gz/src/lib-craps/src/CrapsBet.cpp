//----------------------------------------------------------------
//
// File: CrapsBet.cpp
//
//----------------------------------------------------------------

#include <craps/CrapsBet.h>
#include <craps/TableRules.h>
#include <algorithm>
#include <cstdint>

#include <cassert>
#include <iostream>
#include <stdexcept> // for std::invalid_argument
#include <craps/CrapsTable.h>
#include <craps/DecisionRecord.h>
#include <craps/Player.h>
#include <craps/Dice.h>
#include <gen/Debug.h>
#include <gen/ErrorPass.h>
#include <gen/Logger.h>
#include <gen/MoneyUtils.h>
#include <gen/StringUtils.h>

using namespace Craps;

unsigned CrapsBet::idCounter_ = 0;

const std::unordered_set<unsigned> CrapsBet::pointNums_   = {4, 5, 6, 8, 9, 10};
const std::unordered_set<unsigned> CrapsBet::fieldNums_   = {2, 3, 4, 9, 10, 11, 12};
const std::unordered_set<unsigned> CrapsBet::crapsNums_   = {2, 3, 12};
const std::unordered_set<unsigned> CrapsBet::bookEnds_    = {2, 3, 11, 12};
const std::unordered_set<unsigned> CrapsBet::hardwayNums_ = {4, 6, 8, 10};

/*-----------------------------------------------------------*//**

Constructor - creates a CrapsBet

Creates a Craps bet. The bet is given a unique ID and time of creation.
The CrapsBet class does not store or use betIds for any purpose. betId
is meant for upper level designs that track many bets.

Arguments are checked for validity and if found to be bad then
std::invalid_argument is thrown.

Note that no check is made at this time whether the bet is allowed to be
placed on a Craps table. CrapsBet is unaware of the state of any Craps
table. This decouples the act of creating a bet from placing a bet on a
CrapsTable, allowing the application better freedom of design.

@param[in] pPlayer
    The player making this bet.

@param[in] name
    The name/type of the bet. Throws if this is not valid name.

@param[in] contractAmount
    The amount of the bet. Throws if this is zero.
    For C&E bets, min bet is 2 must be a multiple of 2.
    For Horn bets, min bet is 4 must be a multiple of 4.
    For World bets, min bet is 5 must be a multiple of 5.

@param[in] pivot
    The number this bet is focused on. For example a Place bet must set
    the pivot to 4,5,6,8,9 or 10 otherwise a std::invalid_argument
    exception is thrown.

    For Field, AnyCraps, AnySeven, C&E, Horn and World bets, the pivot is
    unused and internally set to 0.

    For PassLine/Come/DontPass/DontCome bets, the caller sets the pivot
    to zero. Zero indicates the pivot number needs to be set later.
    These point-based bets get their pivot number assigned during
    CrapsBet::evaluate(),

    As a special case only for PassLine bets, the caller may also
    explicitly set the pivot to one of 4,5,6,8,9 or10. This supports the
    behavior of putting down a PassLine bet after the point is already
    established.

    Note that CrapsBet constructor knows nothing about the state of the
    Craps table. It is the responsibility of the caller to ensure the
    bet is permissable and placed on a Craps table at the right time.

    For PassLine bets, if somehow a pivot is zero and the bet is being
    evaluated after a point has already been established, then the pivot
    is silently assigned to the already established point, as if the player
    made a PassLine bet after the point was established.
*/
CrapsBet::CrapsBet(
    Player*    pPlayer,
    BetName    name,
    Gen::Money contractAmount,
    unsigned   pivot)
    : pPlayer_(pPlayer)
    , betId_  (++idCounter_)
    , betName_(name)
    , pivot_  (pivot)
    , contractAmount_(contractAmount)
{
    try
    {
        if (pPlayer_ == nullptr)
        {
            throw std::invalid_argument("Bad \"pPlayer\": cannot be nullptr.");
        }
        checkBetName();         // throws
        checkContractAmount();  // throws
        checkLinePivot();       // throws
        checkPlacePivot();      // throws
        checkHardwayPivot();    // throws
        checkSideBets();        // throws
    }
    catch(std::invalid_argument& e)
    {
        std::string s = "CrapsBet()::ctor: Unable to create bet; ";
        throw std::invalid_argument(s + e.what());
    }
}

//----------------------------------------------------------------

void
CrapsBet::checkBetName()
{
    const auto it = std::find(EnumBetName::enumerators.begin(),
                              EnumBetName::enumerators.end(), betName_);
    if (it == EnumBetName::enumerators.end())
    {
        throw std::invalid_argument(
            "Bad \"betName\": must be a valid craps bet name; "
            "BetName::Count, BetName::Invalid, and unknown values are not valid bets.");
    }
}

//----------------------------------------------------------------

void
CrapsBet::checkContractAmount()
{
    if (contractAmount_ == 0)
    {
        throw std::invalid_argument("Bad \"contractAmount\":$0 must be > $0.");
    }
}

//----------------------------------------------------------------

void
CrapsBet::checkLinePivot()
{
    if (betName_ == BetName::PassLine ||
        betName_ == BetName::Come     ||
        betName_ == BetName::DontPass ||
        betName_ == BetName::DontCome)
    {
        if (!pointNums_.contains(pivot_) && pivot_ != 0)
        {
            std::string diag = "Bad \"pivot\":" + std::to_string(pivot_) +
                " for PassLine|Come|DontPass|Dontcome bet; "
                "pivot must be 0,4,5,6,8,9 or 10.";
            throw std::invalid_argument(diag);
        }
    }
}

//----------------------------------------------------------------

void
CrapsBet::checkPlacePivot()
{
    if (betName_ == BetName::Place ||
        betName_ == BetName::Lay   ||
        betName_ == BetName::Buy)
    {
        if (!pointNums_.contains(pivot_))
        {
            std::string diag = "Bad \"pivot\":" + std::to_string(pivot_) +
                " for a Place, Buy, or Lay bet; "
                "pivot must be 0,4,5,6,8,9 or 10.";
            throw std::invalid_argument(diag);
        }
    }
}

//----------------------------------------------------------------

void
CrapsBet::checkHardwayPivot()
{
    if (betName_ == BetName::Hardway)
    {
        offComeOutRoll_ = false;  // For hardways, default is  always working
        if (!hardwayNums_.contains(pivot_))
        {
            std::string diag = "Bad \"pivot\":" + std::to_string(pivot_) +
                " for a Hardway bet; pivot must be one of 4,6,8,10";
            throw std::invalid_argument(diag);
        }
    }
}

//----------------------------------------------------------------

void
CrapsBet::checkSideBets()
{
    if (betName_ == BetName::Field    ||
        betName_ == BetName::AnyCraps ||
        betName_ == BetName::AnySeven ||
        betName_ == BetName::CandE    ||
        betName_ == BetName::Horn     ||
        betName_ == BetName::World)
    {
        pivot_ = 0;  // Quietly force it to 0.
    }
}

//----------------------------------------------------------------

bool
CrapsBet::operator==(const CrapsBet& other) const
{
    return pPlayer_        == other.pPlayer_        &&
           betId_          == other.betId_          &&
           pivot_          == other.pivot_          &&
           contractAmount_ == other.contractAmount_ &&
           oddsAmount_     == other.oddsAmount_     &&
           placementCommission_ == other.placementCommission_ &&
           hasDecision_ == other.hasDecision_ &&
           offComeOutRoll_ == other.offComeOutRoll_ &&
           distance_       == other.distance_       &&
           whenCreated_    == other.whenCreated_    &&
           whenDecided_    == other.whenDecided_;
}

/*-----------------------------------------------------------*//**

Sets the contract bet to the given amount.

Private function called by CrapsTable. CrapsTable is trusted
so just overwrites value. No checks needed.

@param[in] amount
    Sets the contract bet amount to amount
*/
void
CrapsBet::setContractAmountInternal(Gen::Money amount)
{
    contractAmount_ = amount;
}

/*-----------------------------------------------------------*//**

Sets the odds amount to the given amount.

Private function called by CrapsTable. CrapsTable is trusted
so just overwrites value. No checks needed.

@param[in] amount
    Sets the odds amount to amount
*/
void
CrapsBet::setOddsAmountInternal(Gen::Money newAmount)
{
    oddsAmount_ = newAmount;
}

//----------------------------------------------------------------

void
CrapsBet::setPlacementCommissionInternal(Gen::Money amount)
{
    placementCommission_ = amount;
}

/*-----------------------------------------------------------*//**

Sets the pivot to the given point.

Private function called by CrapsTable. CrapsTable is trusted
so just overwrites value. No checks needed.

@param[in] pivot
    Sets the pivot to point
*/
void
CrapsBet::setPivotInternal(unsigned pivot)
{
    pivot_ = pivot;
}

/*-----------------------------------------------------------*//**

Sets the distance to the given number.

Private function called by unit tests
so just overwrites value. No checks needed.

@param[in] distance
    Sets the distance
*/
void
CrapsBet::setDistanceInternal(unsigned distance)
{
    distance_ = distance;
}

/*-----------------------------------------------------------*//**

Evaluates a CrapsBet for win/lose.

Using the given point and the current dice roll, evaluate() determines
whether this bet has won, lost or not yet reached a decision. The
results of the evaluation are returned in a DecisionRecord.

Payout strategy:

@li Pay full odds on the largest multiple of the payout unit
@li Pay remaining amount at 1:1
@li Rounds down in favor of house (like casinos)

@param [in] point
    supply 0 to indicate a come out roll, otherwise the current point
    which must be one of 4,5,6,8,9 or 10. If not then an error is
    returned and ep holds the reason.

@param [in] dice
    the dice roll to evaluate

@param [out] dr
    The DecisionRecord contains the results of the evaluation.
    If successful then dr has valid contents, otherwise
    dr should be ignored and ep has description of the error.

@param [out] ep
    If evaluation fails, then ep describes the error.
*/
Gen::ReturnCode
CrapsBet::evaluate(unsigned point, const Dice& dice,
                   DecisionRecord& dr, Gen::ErrorPass& ep)
{
    static const TableRules defaultRules{};
    return evaluate(point, dice, defaultRules, dr, ep);
}

Gen::ReturnCode
CrapsBet::evaluate(unsigned point, const Dice& dice,
                   const TableRules& rules,
                   DecisionRecord& dr, Gen::ErrorPass& ep)
{
    D(diagEvalEntered(point, dice);)
    if (!validArgsEval(point, ep))
    {
        return diagEvalProcError(ep);
    }

    dr = {this, false, false, 0,0,0,0};   // Prepare decision record
    Gen::ReturnCode rc = Gen::ReturnCode::Fail;
    switch (betName_)
    {
        case BetName::PassLine: rc = evalPassLine(point, dice, rules, dr, ep); break;
        case BetName::Come    : rc = evalCome    (point, dice, rules, dr, ep); break;
        case BetName::DontPass: rc = evalDontPass(point, dice, rules, dr, ep); break;
        case BetName::DontCome: rc = evalDontCome(point, dice, rules, dr, ep); break;
        case BetName::Place   : rc = evalPlace   (point, dice, rules, dr, ep); break;
        case BetName::Buy     : rc = evalBuy     (point, dice, rules, dr, ep); break;
        case BetName::Lay     : rc = evalLay     (point, dice, rules, dr, ep); break;
        case BetName::Hardway : rc = evalHardway (point, dice, dr, ep); break;
        case BetName::Field   : rc = evalField   (point, dice, rules, dr, ep); break;
        case BetName::AnyCraps: rc = evalAnyCraps(point, dice, dr, ep); break;
        case BetName::AnySeven: rc = evalAnySeven(point, dice, dr, ep); break;
        case BetName::CandE   : rc = evalCandE   (point, dice, dr, ep); break;
        case BetName::Horn    : rc = evalHorn    (point, dice, dr, ep); break;
        case BetName::World   : rc = evalWorld   (point, dice, dr, ep); break;
        case BetName::Count   : // fall through
        case BetName::Invalid : return Gen::ReturnCode::Fail;           break;
    }
    if (rc == Gen::ReturnCode::Fail)
    {
        return diagEvalProcError(ep);
    }
    distance_++;
    dr.removeBet = dr.decision;
    if (dr.decision)
    {
        hasDecision_ = true;
        whenDecided_.setToNow();

        // These wagers pay a winning outcome but remain active until they
        // lose or the player removes them. Their original stake therefore
        // remains on the table after a win.
        if (dr.win > 0 &&
            (betName_ == BetName::Place ||
             betName_ == BetName::Buy   ||
             betName_ == BetName::Lay   ||
             betName_ == BetName::Hardway))
        {
            dr.removeBet = false;
        }
    }
    return Gen::ReturnCode::Success;
}

//----------------------------------------------------------------

void
CrapsBet::diagEvalEntered(unsigned point, const Dice& dice) const
{
    LOG_TRACE("CrapsBet::evaluate(point:" + std::to_string(point) +
              " " + dice.toString());
}

//----------------------------------------------------------------

Gen::ReturnCode
CrapsBet::diagEvalProcError(Gen::ErrorPass& ep) const
{
    std::string s("CrapsBet::evaluate(): Error evaluating betId:");
    ep.prepend(s + diagBetId() + ". ");
    return Gen::ReturnCode::Fail;
}

//----------------------------------------------------------------

std::string
CrapsBet::diagBetId() const
{
    std::string s = "bet(betName:" + EnumBetName::toString(betName_);
    if (pivot_ != 0)
    {
        s += "(" + std::to_string(pivot_) + ")";
    }
    s += " betId:" + std::to_string(betId_) + ")";
    return s;
}

//----------------------------------------------------------------

bool
CrapsBet::validArgsEval(unsigned point, Gen::ErrorPass& ep) const
{
    if (pointNums_.contains(point) || point == 0)
    {
        return true;
    }
    ep.setDescription("Bad value for point:" + std::to_string(point));
    return false;
}

//----------------------------------------------------------------
//
// Payout Logic. Suitable for both positive and inverted odds.
//
Gen::Money
CrapsBet::calculateOddsPayout(
    Gen::Money amount,
    unsigned numerator,
    unsigned denominator,
    TableRules::PayoutRounding rounding,
    Gen::Money payoutUnit) const
{
    if (denominator == 0) return 0;
    const auto gross = static_cast<std::uint64_t>(amount) * numerator;
    Gen::Money payout = static_cast<Gen::Money>(gross / denominator);
    if (rounding == TableRules::PayoutRounding::Down &&
        payoutUnit > 1)
    {
        payout = (payout / payoutUnit) * payoutUnit;
    }
    return payout;
}

//----------------------------------------------------------------

Gen::Money
CrapsBet::calculateCommission(
    Gen::Money grossWin,
    Gen::Money wager,
    const TableRules::Commission& rules) const
{
    if (rules.collection == TableRules::CommissionCollection::OnPlacement)
        return 0; // Already collected when the bet was accepted.

    const Gen::Money basis = rules.basis == TableRules::CommissionBasis::OnWager
        ? wager : grossWin;
    const auto raw = static_cast<std::uint64_t>(basis) * rules.basisPoints;
    Gen::Money commission = static_cast<Gen::Money>(raw / 10000);
    if (rules.rounding == TableRules::PayoutRounding::Down &&
        rules.roundingUnit > 1)
    {
        commission = (commission / rules.roundingUnit) * rules.roundingUnit;
    }
    if (basis > 0 && commission < rules.minimum)
        commission = rules.minimum;
    return commission;
}

//----------------------------------------------------------------
//
// Strategy:
//
// * Odds payout only on even multiples of the true odds.
// * Uneven remainders should pay 1:1 for any leftover amount
//   above a full multiple.
// * Amounts below a full multiple get paid 1:1 only.
//
void
CrapsBet::calcWinPointBet(
    unsigned pivot,
    DecisionRecord& dr,
    bool returnOdds,
    const OddsTables::OddsEntry table[],
    const TableRules& rules) const
{
    dr.win = contractAmount_;

    if (oddsAmount_ == 0) return;

    if (offComeOutRoll_ && returnOdds)
    {
        dr.returnToPlayer = oddsAmount_;
        return;  // Skip odds payout calculation
    }

    const auto& odds = table[pivot];
    unsigned oddsPayout = calculateOddsPayout(oddsAmount_,
                                              odds.numerator,
                                              odds.denominator, rules.odds.rounding, rules.odds.payoutUnit);
    dr.win += oddsPayout;
}

//----------------------------------------------------------------

void
CrapsBet::calcLossPointBet(DecisionRecord& dr, bool returnOdds) const
{
    dr.lose = contractAmount_;
    if (oddsAmount_ == 0) return;
    if (offComeOutRoll_ && returnOdds)
    {
        dr.returnToPlayer = oddsAmount_;
    }
    else
    {
        dr.lose += oddsAmount_;
    }
}

//----------------------------------------------------------------

Gen::ReturnCode
CrapsBet::evalPassLine(
    unsigned point,
    const Dice& dice,
    const TableRules& rules,
    DecisionRecord& dr,
    Gen::ErrorPass& ep)
{
    (void) ep; // unused, quiet the compiler
    Decision dcn = Keep;
    unsigned d = dice.value(); // Cache value once

    if (point == 0)
    {
        if (d == 7 || d == 11)
        {
            dcn = Win;
        }
        else if (crapsNums_.contains(d))
        {
            dcn = Lose;
        }
        else
        {
            pivot_ = d;
            dr.pivotAssigned = true;
            dcn = Keep;
        }
    }
    else
    {
        if (pivot_ == 0)
        {
            // Special case handing for pass bet. PassLine bet made
            // after come out roll, which is legal. Caller should have
            // have assigned it a pivot, but didn't so we'll do that
            // quietly.
            pivot_ = point;
            dr.pivotAssigned = true;
        }
        if (d == 7)
        {
            dcn = Lose;
        }
        else if (pivot_ == d)
        {
            dcn = Win;
        }
        // else dcn = Keep;
    }

    const bool returnOdds = false;
    if (dcn == Win)  calcWinPointBet(d, dr, returnOdds, OddsTables::oddsPass, rules);
    if (dcn == Lose) calcLossPointBet (dr, returnOdds);
    dr.decision = (dcn != Keep);
    return Gen::ReturnCode::Success;
}

//----------------------------------------------------------------

Gen::ReturnCode
CrapsBet::evalCome(
    unsigned point,
    const Dice& dice,
    const TableRules& rules,
    DecisionRecord& dr,
    Gen::ErrorPass& ep)
{
    if (point == 0 && pivot_ == 0)
    {
        // This bet is in the wrong state. It should not be on the
        // table. This means a Come bet was placed on the table
        // during a come out roll, which is illegal. Instead the
        // user must make a PassLine bet.
        //
        ep.setDescription("Come bet is not allowed on come out roll. "
                          "Use PassLine bet instead.");
        return Gen::ReturnCode::Fail;
    }

    Decision dcn = Keep;
    bool returnOdds = false;
    unsigned d = dice.value(); // Cache value once

    if (point == 0)  // Come out roll (for the table)
    {
        if (d == 7)
        {
            dcn = Lose;
            returnOdds = true;
        }
        else if (bookEnds_.contains(d))
        {
            dcn = Keep;
        }
        else if (pivot_ == d)
        {
            dcn = Win;
            returnOdds = true;
        }
        // else dcn = Keep;
    }
    else
    {
        if (pivot_ == 0)  // Come bet freshly placed on table.
        {
            if (d == 7 || d == 11)
            {
                dcn = Win;
            }
            else if (crapsNums_.contains(d))
            {
                dcn = Lose;
            }
            else
            {
                pivot_ = d;
                dr.pivotAssigned = true;
                dcn = Keep;
            }
        }
        else   // Waiting for a repeating number.
        {
            if (d == 7)
            {
                dcn = Lose;
            }
            else if (pivot_ == d)
            {
                dcn = Win;
            }
            // else dcn == keep;
        }
    }

    if (dcn == Win)  calcWinPointBet(d, dr, returnOdds, OddsTables::oddsPass, rules);
    if (dcn == Lose) calcLossPointBet (dr, returnOdds);
    dr.decision = (dcn != Keep);
    return Gen::ReturnCode::Success;
}

//----------------------------------------------------------------

Gen::ReturnCode
CrapsBet::evalDontPass(
    unsigned point,
    const Dice& dice,
    const TableRules& rules,
    DecisionRecord& dr,
    Gen::ErrorPass& ep)
{
    Decision dcn = Keep;
    unsigned d = dice.value();  // Cache value once

    if ((point != 0) && (pivot_ == 0))
    {
        // This bet is in the wrong state, it should not be on the
        // table.  It means the DontPass bet was placed on the table
        // after the point was already established, which is illegal for
        // a DontPass bet. DontPass must sit through come roll
        // evaluation(s) in order to be assigned a pivot, thus if there
        // is a point, then pivot cannot be zero.
        //
        ep.setDescription("DontPass bet is not allowed after point "
                          "is established.");
        return Gen::ReturnCode::Fail;
    }

    if (point == 0)  // come out roll
    {
        if (d == 7 || d == 11)
        {
            dcn = Lose;
        }
        else if (d == 2 || d == 3)
        {
            dcn = Win;
        }
        else if (d == 12)
        {
            dcn = Keep;
        }
        else
        {
            pivot_ = d;
            dr.pivotAssigned = true;
            dcn = Keep;
        }
    }
    else
    {
        if (d == 7)
        {
            dcn = Win;
        }
        else if (pivot_ == d)
        {
            dcn = Lose;
        }
        // else dcn = Keep;
    }

    const bool returnOdds = false;
    if (dcn == Win) calcWinPointBet(pivot_, dr, returnOdds, OddsTables::oddsDont, rules);
    if (dcn == Lose) calcLossPointBet (dr, returnOdds);
    dr.decision = (dcn != Keep);
    return Gen::ReturnCode::Success;
}

//----------------------------------------------------------------

Gen::ReturnCode
CrapsBet::evalDontCome(
    unsigned point,
    const Dice& dice,
    const TableRules& rules,
    DecisionRecord& dr,
    Gen::ErrorPass& ep)
{
    if (point == 0 && pivot_ == 0)
    {
        // This bet is in the wrong state. It should not be on the
        // table. This means a DontCome bet was placed on the table
        // during a come out roll, which is illegal. Instead the
        // user must make a DontPass bet.
        //
        ep.setDescription("DontCome bet is not allowed on Come out "
                          "roll. Use DontPass bet instead.");
        return Gen::ReturnCode::Fail;
    }

    Decision dcn = Keep;
    bool returnOdds = false;
    unsigned d = dice.value(); // Cache value once

    if (point == 0)  // Come out roll (for the table)
    {
        if (d == 7)
        {
            dcn = Win;
            returnOdds = true;
        }
        else if (bookEnds_.contains(d))
        {
            dcn = Keep;
        }
        else if (pivot_ == d)
        {
            dcn = Lose;
            returnOdds = true;
        }
        // else dcn = Keep;
    }
    else
    {
        if (pivot_ == 0)  // DontCome bet freshly placed on table.
        {
            if (d == 7 || d == 11)
            {
                dcn = Lose;
            }
            else if (d == 2 || d == 3)
            {
                dcn = Win;
            }
            else if (d == 12)
            {
                dcn = Keep;
            }
            else
            {
                pivot_ = d;
                dr.pivotAssigned = true;
                dcn = Keep;
            }
        }
        else   // Waiting for a 7 before number repeats.
        {
            if (d == 7)
            {
                dcn = Win;
            }
            else if (pivot_ == d)
            {
                dcn = Lose;
            }
            // else dcn == keep;
        }
    }

    if (dcn == Win)  calcWinPointBet(pivot_, dr, returnOdds, OddsTables::oddsDont, rules);
    if (dcn == Lose) calcLossPointBet (dr, returnOdds);
    dr.decision = (dcn != Keep);
    return Gen::ReturnCode::Success;
}

//----------------------------------------------------------------

Gen::ReturnCode
CrapsBet::evalPlace(
    unsigned point,
    const Dice& dice,
    const TableRules& rules,
    DecisionRecord& dr,
    Gen::ErrorPass& ep)
{
    (void) ep;
    Decision dcn = Keep;

    if (point == 0 && offComeOutRoll_)
    {
        dcn = Keep;
    }
    else
    {
        if (dice.value() == 7)
        {
            dcn = Lose;
        }
        if (pivot_ == dice.value())
        {
            dcn = Win;
        }
        // else dcn = keep
    }

    if (dcn == Win)
    {
        const auto& odds = OddsTables::oddsPlace[pivot_];
        dr.win = calculateOddsPayout(contractAmount_,
                                     odds.numerator,
                                     odds.denominator, rules.payoutRounding, rules.payoutUnit);
    }
    
    if (dcn == Lose)
    {
        dr.lose = contractAmount_;
    }
    dr.decision = (dcn != Keep);
    return Gen::ReturnCode::Success;
}

//----------------------------------------------------------------

Gen::ReturnCode
CrapsBet::evalLay(
    unsigned point,
    const Dice& dice,
    const TableRules& rules,
    DecisionRecord& dr,
    Gen::ErrorPass& ep)
{
    (void) ep;
    Decision dcn = Keep;

    if (point == 0 && offComeOutRoll_)
    {
        dcn = Keep;
    }
    else
    {
        if (dice.value() == 7)
        {
            dcn = Win;
        }
        if (pivot_ == dice.value())
        {
            dcn = Lose;
        }
        // else dcn = keep
    }

    if (dcn == Win)
    {
        const auto& odds = OddsTables::oddsDont[pivot_];
        dr.win = calculateOddsPayout(contractAmount_,
                                     odds.numerator,
                                     odds.denominator, rules.odds.rounding, rules.odds.payoutUnit);
        dr.commission = calculateCommission(dr.win, contractAmount_,
                                            rules.layCommission);
        dr.win -= dr.commission;
    }
    if (dcn == Lose)
    {
        dr.lose = contractAmount_;
    }
    dr.decision = (dcn != Keep);
    return Gen::ReturnCode::Success;
}

//----------------------------------------------------------------

Gen::ReturnCode
CrapsBet::evalBuy(
    unsigned point,
    const Dice& dice,
    const TableRules& rules,
    DecisionRecord& dr,
    Gen::ErrorPass& ep)
{
    (void) ep;
    Decision dcn = Keep;

    if (point == 0 && offComeOutRoll_)
    {
        dcn = Keep;
    }
    else
    {
        if (dice.value() == 7)
        {
            dcn = Lose;
        }
        if (pivot_ == dice.value())
        {
            dcn = Win;
        }
        // else dcn = keep
    }

    if (dcn == Win)
    {
        const auto& odds = OddsTables::oddsPass[pivot_];
        dr.win = calculateOddsPayout(contractAmount_,
                                     odds.numerator,
                                     odds.denominator, rules.odds.rounding, rules.odds.payoutUnit);
        dr.commission = calculateCommission(dr.win, contractAmount_,
                                            rules.buyCommission);
        dr.win -= dr.commission;
    }
    if (dcn == Lose)
    {
        dr.lose = contractAmount_;
    }
    dr.decision = (dcn != Keep);
    return Gen::ReturnCode::Success;
}

//----------------------------------------------------------------

Gen::ReturnCode
CrapsBet::evalField(
    unsigned point,
    const Dice& dice,
    const TableRules& rules,
    DecisionRecord& dr,
    Gen::ErrorPass& ep)
{
    (void) ep; (void) point;  // unused, quiet the compiler
    Decision dcn = Keep;
    unsigned d = dice.value();  // cache value once

    // For field bets, in additon to win/lose we also set the pivot.
    // Allows us to keeps stats on field bet win/lose per number.

    if (d == 5 || d == 6 || d == 7 || d == 8)
    {
        dcn = Lose;
        pivot_ = d;
    }
    else
    {
        dcn = Win;
        pivot_ = d;
    }

    if (dcn == Win)
    {
        const auto& odds = rules.fieldPayouts[d];
        if (odds.numerator == 0)
        {
            ep.setDescription("No Field payout is configured for dice total " +
                              std::to_string(d) + ".");
            return Gen::ReturnCode::Fail;
        }
        const Gen::Money rawPayout =
            (contractAmount_ * odds.numerator) / odds.denominator;
        if (rules.payoutRounding == TableRules::PayoutRounding::Down)
            dr.win = (rawPayout / rules.payoutUnit) * rules.payoutUnit;
        else
            dr.win = rawPayout;
    }
    if (dcn == Lose)
    {
        dr.lose = contractAmount_;
    }
    dr.decision = (dcn != Keep);
    return Gen::ReturnCode::Success;
}

//----------------------------------------------------------------

Gen::ReturnCode
CrapsBet::evalHardway(
    unsigned point,
    const Dice& dice,
    DecisionRecord& dr,
    Gen::ErrorPass& ep)
{
    (void) ep; (void) point;  // unused, quiet the compiler
    Decision dcn = Keep;

    if (offComeOutRoll_)
    {
        dcn = Keep;
    }
    else if (dice.value() == 7)
    {
        dcn = Lose;
    }
    else if (dice.value() == pivot_)
    {
        if (dice.d1() == dice.d2())
        {
            dcn = Win;
        }
        else
        {
            dcn = Lose;
        }
    }
    // else dcn = Keep

    if (dcn == Win)
    {
        dr.win = (contractAmount_ * OddsTables::oddsHardway[pivot_].numerator) /
            OddsTables::oddsHardway[pivot_].denominator;
    }
    if (dcn == Lose)
    {
        dr.lose = contractAmount_;
    }
    dr.decision = (dcn != Keep);
    return Gen::ReturnCode::Success;
}

//----------------------------------------------------------------

Gen::ReturnCode
CrapsBet::evalAnyCraps(
    unsigned point,
    const Dice& dice,
    DecisionRecord& dr,
    Gen::ErrorPass& ep)
{
    (void) ep; (void) point;  // unused, quiet the compiler

    if (crapsNums_.contains(dice.value()))
    {
        dr.win = contractAmount_ * 7;
    }
    else
    {
        dr.lose = contractAmount_;
    }
    dr.decision = true;
    return Gen::ReturnCode::Success;
}

//----------------------------------------------------------------

Gen::ReturnCode
CrapsBet::evalAnySeven(
    unsigned point,
    const Dice& dice,
    DecisionRecord& dr,
    Gen::ErrorPass& ep)
{
    (void) ep; (void) point;  // unused, quiet the compiler

    if (dice.value() == 7)
    {
        dr.win = contractAmount_ * 4;
    }
    else
    {
        dr.lose = contractAmount_;
    }
    dr.decision = true;
    return Gen::ReturnCode::Success;
}

//----------------------------------------------------------------

Gen::ReturnCode
CrapsBet::evalCandE(
    unsigned point,
    const Dice& dice,
    DecisionRecord& dr,
    Gen::ErrorPass& ep)
{
    (void) ep; (void) point;  // unused, quiet the compiler

    if (dice.value() == 11)
    {
        dr.win = (contractAmount_ / 2) * 15;
    }
    else if (crapsNums_.contains(dice.value()))
    {
        dr.win = (contractAmount_ / 2) * 7;
    }
    else
    {
        dr.lose = contractAmount_;
    }
    dr.decision = true;
    return Gen::ReturnCode::Success;
}

//----------------------------------------------------------------

Gen::ReturnCode
CrapsBet::evalHorn(
    unsigned point,
    const Dice& dice,
    DecisionRecord& dr,
    Gen::ErrorPass& ep)
{
    (void) ep; (void) point;  // unused, quiet the compiler

    if (dice.value() == 2 || dice.value() == 12)
    {
        dr.win = (contractAmount_ / 4) * 30;
    }
    else if (dice.value() == 3 || dice.value() == 11)
    {
        dr.win = (contractAmount_ / 4) * 15;
    }
    else
    {
        dr.lose = contractAmount_;
    }
    dr.decision = true;
    return Gen::ReturnCode::Success;
}

//----------------------------------------------------------------

Gen::ReturnCode
CrapsBet::evalWorld(
    unsigned point,
    const Dice& dice,
    DecisionRecord& dr,
    Gen::ErrorPass& ep)
{
    (void) point;  // World is a one-roll proposition bet.

    // Table validation normally guarantees this. Keep evaluation safe when
    // called directly by tests or another model client with an invalid wager.
    if (contractAmount_ < 5 || contractAmount_ % 5 != 0)
    {
        ep.setDescription("World bet amount must be a multiple of 5 and at least 5.");
        return Gen::ReturnCode::Fail;
    }

    const auto& odds = OddsTables::oddsWorld[dice.value()];
    if (odds.numerator != 0)
    {
        // The total wager is five equal components: 2, 3, 7, 11 and 12.
        // The winning component pays its stated profit, while the other four
        // component stakes are lost. dr.win is the net profit for the whole
        // World wager. A 7 is therefore a break-even outcome (4 - 4 = 0).
        const Gen::Money component = contractAmount_ / 5;
        const Gen::Money componentProfit =
            component * odds.numerator / odds.denominator;
        const Gen::Money losingComponents = contractAmount_ - component;
        dr.win = componentProfit - losingComponents;
    }
    else
    {
        dr.lose = contractAmount_;
    }
    dr.decision = true;
    return Gen::ReturnCode::Success;
}

/*-----------------------------------------------------------*//**

Returns the player associated with this bet.

@return
    Pointer to the player
*/
Player&
CrapsBet::player() const
{
    return *pPlayer_;
}

/*-----------------------------------------------------------*//**

Returns the bet ID.

@return
    The unique bet ID associated with this bet.
*/
BetId
CrapsBet::betId() const
{
    return betId_;
}

/*-----------------------------------------------------------*//**

Returns the bet name/type.

@return
    The bet name/type.
*/
BetName
CrapsBet::betName() const
{
    return betName_;
}

/*-----------------------------------------------------------*//**

Returns the pivot.

The pivot is the focus number for this bet. For example a Place bet will
have a pivot of 4,5,6,8,9, or 10. For initial Pass/Come/DontCome/DontPass bets,
the pivot is zero indicating a point number is not yet established.

@return
    The pivot.
*/
unsigned
CrapsBet::pivot() const
{
    return pivot_;
}

/*-----------------------------------------------------------*//**

Returns the contract amount of the bet.

Contract amount does not include the odds amount.

@return
    The contract amount.
*/
unsigned
CrapsBet::contractAmount() const
{
    return contractAmount_;
}

/*-----------------------------------------------------------*//**

Returns the odds amount of the bet.

Odd amount does not include the contract amount.

@return
    The odds amount.
*/
unsigned
CrapsBet::oddsAmount() const
{
    return oddsAmount_;
}

//----------------------------------------------------------------

Gen::Money
CrapsBet::placementCommission() const
{
    return placementCommission_;
}

//----------------------------------------------------------------

bool
CrapsBet::hasDecision() const
{
    return hasDecision_;
}

/*-----------------------------------------------------------*//**

Returns whether the bet is "working/on" or "not-working/off" on a
come out roll.

For point bets (PassLine|Come|DontPass|DontCome), this refers to the
odds amount.

@return
    true if "off" on come out roll, false otherwise.
*/
bool
CrapsBet::offComeOutRoll() const
{
    return offComeOutRoll_;
}

/*-----------------------------------------------------------*//**

Returns whether Hardway bet is "working/on" or "not-working/off".

@return
    true if "working", false otherwise.
*/
bool
CrapsBet::hardwayWorking() const
{
    return !offComeOutRoll_;
}

/*-----------------------------------------------------------*//**

Set this bet to be off on come out rolls.

Off is the default,
*/
void
CrapsBet::setOffComeOutRoll()
{
    offComeOutRoll_ = true;
}

/*-----------------------------------------------------------*//**

Set this bet to be working on come out rolls.

Off is the default.
*/
void
CrapsBet::setOnComeOutRoll()
{
    offComeOutRoll_ = false;
}

/*-----------------------------------------------------------*//**

Set this Hardway bet to "working".

Working is the default for a Hardway bet.

If this bet is not a Hardway bet, then just silently returns.
*/
void
CrapsBet::setHardwayOn()
{
    if (betName_ != BetName::Hardway) return;
    offComeOutRoll_ = false;
}

/*-----------------------------------------------------------*//**

Set this Hardway bet to "off".

Working is the default for a Hardway bet.

If this bet is not a Hardway bet, then just silently returns.
*/
void
CrapsBet::setHardwayOff()
{
    if (betName_ != BetName::Hardway) return;
    offComeOutRoll_ = true;
}

/*-----------------------------------------------------------*//**

Returns the number of dice rolls to reach a decision.

If a decision is not yet reached it is the number of
dice rolls so far.

@return
    number of dice rolls so far to reach a decision.
*/
unsigned
CrapsBet::distance() const
{
    return distance_;
}

/*-----------------------------------------------------------*//**

Returns the time of the bet creation.

@return
    time of bet creation.
*/
Gen::Timepoint
CrapsBet::whenCreated() const
{
    return whenCreated_;
}

/*-----------------------------------------------------------*//**

Returns the time the bet reached a decision.

@return
    time of bet decision.
*/
Gen::Timepoint
CrapsBet::whenDecided() const
{
    return whenDecided_;
}

//----------------------------------------------------------------

void
CrapsBet::logBet(std::string_view intro) const
{
    std::stringstream s;
    s << "\n" << intro << "\n" << *this;
    LOG_INFO(s.str());
}

//----------------------------------------------------------------

std::ostream&
operator<< (std::ostream& out, const CrapsBet& b)
{
    out <<
    "        player: " << b.player().getName() << std::endl <<
    "         betId: " << b.betId()            << std::endl <<
    "       betName: " << b.betName()          << std::endl <<
    "         pivot: " << b.pivot()            << std::endl <<
    "contractAmount: " << b.contractAmount()   << std::endl <<
    "    oddsAmount: " << b.oddsAmount()       << std::endl <<
    "offComeOutRoll: " << b.offComeOutRoll()   << std::endl <<
    "      distance: " << b.distance()         << std::endl <<
    "   whenCreated: " << b.whenCreated()      << std::endl <<
    "   whenDecided: " << b.whenDecided()      << std::endl;
    return out;
}

//----------------------------------------------------------------

std::ostream&
operator<< (std::ostream& out, const DecisionRecord& dr)
{
    out <<
    "        player: " << dr.pBet->player().getName() << std::endl <<
    "         betId: " << dr.pBet->betId()            << std::endl <<
    "      decision: " << dr.decision                 << std::endl <<
    " pivotAssigned: " << dr.pivotAssigned            << std::endl <<
    "           win: " << dr.win                      << std::endl <<
    "          lose: " << dr.lose                     << std::endl <<
    "returnToPlayer: " << dr.returnToPlayer           << std::endl <<
    "    commission: " << dr.commission               << std::endl <<
    "     removeBet: " << dr.removeBet                << std::endl;
    return out;
}

//----------------------------------------------------------------
