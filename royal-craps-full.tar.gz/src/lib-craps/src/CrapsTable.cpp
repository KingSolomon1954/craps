//----------------------------------------------------------------
//
// File: CrapsTable.cpp
//
//----------------------------------------------------------------

#include <craps/CrapsTable.h>
#include <craps/Player.h>
#include <controller/GameEvents.h>
#include <controller/Globals.h>
#include <gen/EventManager.h>
#include <gen/Logger.h>
#include <fmt/format.h>
#include <algorithm>
#include <iterator>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <memory>
#include <stdexcept>

using namespace Craps;

/*-----------------------------------------------------------*//**

Constructor.

*/
CrapsTable::CrapsTable(const TableId&     tableId,
                       const TableConfig& config)
    : tableId_(tableId)
    , config_(config)
    , houseBank_(InitialStartingBankBalance_, RefillThreshold_, RefillAmount_)
{
    alltimeStats_.sessionHistory.setMaxSessions(config_.maxSessions);
}

/*-----------------------------------------------------------*//**

Construct Table from in-memory YAML string.

The string is the table's own state, the same thing toYAML() produces.
Throws upon error.

*/
CrapsTable*
CrapsTable::fromString(std::string        yaml,
                       const TableId&     tableId,
                       const TableConfig& config)
{
    std::unique_ptr<CrapsTable> ct(new CrapsTable(tableId, config));
    YAML::Node root = YAML::Load(yaml);
    ct->fromYAML(root);                   // throws
    return ct.release();
}

//-----------------------------------------------------------------

YAML::Node
CrapsTable::toYAML() const
{
    YAML::Node node;
    node["tableId"]          = tableId_;
    node["tableName"]        = tableName_;
    node["shortDescription"] = shortDescription_;
    node["fullDescription"]  = fullDescription_;

    node["Rules"] = rulesToYAML();
    node["Bank"]  = houseBank_.toYAML();
    alltimeStats_.toYAML(node);
    return node;
}

//-----------------------------------------------------------------

void
CrapsTable::fromYAML(const YAML::Node& node)
{
    auto tableIdInFile = node["tableId"].as<std::string>();
    tableName_         = node["tableName"].as<std::string>();
    shortDescription_  = node["shortDescription"].as<std::string>();
    fullDescription_   = node["fullDescription"].as<std::string>();

    // YAML tableId must agree with id from ctor
    if (tableIdInFile != tableId_)
    {
        throw std::runtime_error("Table ID mismatch: expected " +
                                 tableId_ + ", found " + tableIdInFile);
    }

    rulesFromYAML(node["Rules"]);
    houseBank_.fromYAML(node["Bank"]);
    alltimeStats_.fromYAML(node);
}

//----------------------------------------------------------------

void
CrapsTable::rulesFromYAML(const YAML::Node& node)
{
    // Read the legacy flat keys for existing table files.  The in-memory
    // representation is now TableRules; the expanded nested YAML format is
    // introduced separately so old user configurations remain loadable.
    auto readLimit = [&](BetName name, const char* minKey, const char* maxKey,
                         Gen::Money defaultMin, Gen::Money defaultMax,
                         Gen::Money defaultIncrement)
    {
        auto& limit = rules_.wagerLimit(name);
        limit.minimum = node[minKey] ? node[minKey].as<Gen::Money>() : defaultMin;
        limit.maximum = node[maxKey] ? node[maxKey].as<Gen::Money>() : defaultMax;
        limit.increment = defaultIncrement;
    };

    rules_.odds.flatMultiplier = node["maxOdds"] ? node["maxOdds"].as<unsigned>() : 5;
    rules_.odds.style = TableRules::OddsLimitStyle::FlatMultiplier;
    readLimit(BetName::PassLine, "minLineBet", "maxLineBet", 5, 1000, 1);
    readLimit(BetName::Come, "minLineBet", "maxLineBet", 5, 1000, 1);
    readLimit(BetName::DontPass, "minLineBet", "maxLineBet", 5, 1000, 1);
    readLimit(BetName::DontCome, "minLineBet", "maxLineBet", 5, 1000, 1);
    readLimit(BetName::Buy, "minLineBet", "maxLineBet", 5, 1000, 1);
    readLimit(BetName::Lay, "minLineBet", "maxLineBet", 5, 1000, 1);
    readLimit(BetName::Place, "minPlaceBet", "maxPlaceBet", 5, 1000, 1);
    readLimit(BetName::Field, "minFieldBet", "maxFieldBet", 1, 1000, 1);
    readLimit(BetName::CandE, "minCandEBet", "maxCandEBet", 2, 1000, 2);
    readLimit(BetName::Horn, "minHornBet", "maxHornBet", 4, 1000, 4);
    readLimit(BetName::World, "minWorldBet", "maxWorldBet", 5, 1000, 5);

    // New nested rules override legacy defaults when present. Legacy files
    // remain readable and retain their historical settings.
    if (node["advanced"])
        rules_.fromYAML(node["advanced"]);
    else
        rules_.validate();
}

//----------------------------------------------------------------

YAML::Node
CrapsTable::rulesToYAML() const
{
    // Preserve the established file format during this migration step.
    YAML::Node node;
    node["maxOdds"] = rules_.odds.flatMultiplier;
    const auto& line = rules_.wagerLimit(BetName::PassLine);
    const auto& place = rules_.wagerLimit(BetName::Place);
    const auto& field = rules_.wagerLimit(BetName::Field);
    const auto& cande = rules_.wagerLimit(BetName::CandE);
    const auto& horn = rules_.wagerLimit(BetName::Horn);
    const auto& world = rules_.wagerLimit(BetName::World);
    node["minLineBet"] = line.minimum;
    node["maxLineBet"] = line.maximum;
    node["minPlaceBet"] = place.minimum;
    node["maxPlaceBet"] = place.maximum;
    node["minFieldBet"] = field.minimum;
    node["maxFieldBet"] = field.maximum;
    node["minCandEBet"] = cande.minimum;
    node["maxCandEBet"] = cande.maximum;
    node["minHornBet"] = horn.minimum;
    node["maxHornBet"] = horn.maximum;
    node["minWorldBet"] = world.minimum;
    node["maxWorldBet"] = world.maximum;
    node["advanced"] = rules_.toYAML();
    return node;
}

//----------------------------------------------------------------
//
// Ends this table: records today's session and merges stats. Writes
// nothing to disk. The caller persists toYAML() afterward (see
// TableManager::shutdown()).
//
// Called when user decides to switch tables, so this one ends.
// Called when exiting program.
//
void
CrapsTable::close()
{
    // Create an entry for today's session. CrapsTable is the only class
    // with visibility to alltimeStats_, players and currentStats_.
    //
    alltimeStats_.sessionHistory.addSessionSummary(
        players_.size(),
        currentStats_.betStats.totNumBetsAllBets,
        houseBank_.getAmtDeposited(),
        houseBank_.getAmtWithdrawn());

    // Merge alltime stats with today's session.
    alltimeStats_.merge(currentStats_);
    houseBank_.mergeStats();
}

//----------------------------------------------------------------
//
//  Clears out players and bets, disable timers, etc.
//  Writes nothing to disk.
//
void
CrapsTable::shutdown()
{
    // First, clear out players
    auto playersCopy = players_;      // copy of player list
    for (auto& player : playersCopy)
    {
        // Give players opportunity to cleanup on their own
        player->shutdown(); // will modify original players_
    }

    assert(getNumBetsOnTable() == 0);  // boo boo problem
    close();  // merges stats, creates session entry
}

//----------------------------------------------------------------

zeus::expected<void, Gen::ErrorPass>
CrapsTable::addPlayer(Player& player)
{
    Gen::ErrorPass ep;
    if (fifMaxPlayers(ep) || fifHavePlayer(player, ep))
    {
        return zeus::unexpected<Gen::ErrorPass>(std::move(ep));
    }
    
    players_.push_back(&player);

    sendEventPlayerJoinedTable(player);
        
    return {};
}

//----------------------------------------------------------------

void
CrapsTable::setShooter(Player& player)
{
    assert(havePlayer(&player));
    pCurrentShooter_ = &player;
}

/*-----------------------------------------------------------*//**

Removes a player and his bets from the table.

Any outstanding bets are abandoned meaning funds are claimed by the
house bank and not returned to the player.  If that is not desired
behavior then first remove player's bets with force
(Player::removeBetForce()) ahead of this call.

@param[in] player
    the player of interest

@return
    Success, otherwise fail and ep holds the reason.
    Fails only if player is not joined to the table.
*/
zeus::expected<void, Gen::ErrorPass>
CrapsTable::removePlayer(Player& player)
{
    if (!havePlayer(&player))
    {
        std::string diag = "Unable to remove player: " +
            player.getName() + ". Player is not at this table.";
        Gen::ErrorPass ep;
        EP_SET(ep, En::NotFoundError, Et::ProcessingError,
               Es::Indeterminate, diag);
        return zeus::unexpected<Gen::ErrorPass>(std::move(ep));
    }

    // If the shooter is leaving, the dice go to the next player at the
    // table, or to nobody if this was the last player.
    Player* newShooter = pCurrentShooter_;
    if (pCurrentShooter_ == &player)
    {
        auto it = std::find(players_.begin(), players_.end(), &player);
        ++it;
        if (it == players_.end())
            it = players_.begin();
        newShooter = (*it != &player) ? *it : nullptr;
    }

    removePlayerBets(&player);   // Bet money given to the house bank.
    removePlayerByPtr(&player);

    if (newShooter != pCurrentShooter_)
    {
        pCurrentShooter_ = newShooter;
        if (newShooter != nullptr)
        {
            Ctrl::UslNewShooter ev;
            ev.playerId = newShooter->getPlayerId();
            Gen::EventManager::instance().publish(ev);
        }
    }

    sendEventPlayerLeftTable(player);
    sendEventTableBetsChanged();
    sendEventTableBalanceChanged();
    
    return {};
}

/*-----------------------------------------------------------*//**

Replaces one player at the table with another.

The leaving player's session ends (Player::endSession()) and any bets
are pulled from the table and returned to him. The joining player takes
the leaving player's seat, so the order of players at the table does not
change, and takes over the dice if the leaving player was the shooter.

Nothing changes unless the replacement can go ahead: the leaving player
must be at the table and the joining player must not be.

@param[in] leaving
    the player at the table who goes away
@param[in] joining
    the player not at the table who takes his place

@return
    Success, otherwise fail and ep has the reason.
*/
zeus::expected<void, Gen::ErrorPass>
CrapsTable::replacePlayer(Player& leaving, Player& joining)
{
    Gen::ErrorPass ep;
    if (!havePlayer(&leaving))
    {
        EP_SET(ep, En::NotFoundError, Et::ProcessingError,
               Es::Indeterminate, "Unable to replace player: " +
               leaving.getName() + ". Player is not at this table.");
        return zeus::unexpected<Gen::ErrorPass>(std::move(ep));
    }
    if (fifHavePlayer(joining, ep))   // Includes replacing a player with himself
    {
        return zeus::unexpected<Gen::ErrorPass>(std::move(ep));
    }

    const auto   seat       = std::distance(
        players_.begin(),
        std::find(players_.begin(), players_.end(), &leaving));
    const bool   wasShooter = (pCurrentShooter_ == &leaving);

    // The dice go to the joining player, not to whoever is next.
    if (wasShooter)
    {
        pCurrentShooter_ = nullptr;
    }

    leaving.endSession();   // Leaves the table, returns bets

    auto result = joining.joinTable(*this);
    if (!result)
    {
        // Should not happen, since a seat has just been freed. Put the
        // leaving player back so the table is as good as it was.
        LOG_ERROR("CrapsTable::replacePlayer(): joining player failed to "
                  "join; restoring leaving player");
        (void) leaving.joinTable(*this);
        if (wasShooter && havePlayer(&leaving))
        {
            pCurrentShooter_ = &leaving;
        }
        return zeus::unexpected<Gen::ErrorPass>(std::move(result).error());
    }

    // joinTable() adds at the end. Move him into the vacated seat.
    players_.splice(std::next(players_.begin(), seat),
                    players_, std::prev(players_.end()));

    if (wasShooter)
    {
        pCurrentShooter_ = &joining;
        Ctrl::UslNewShooter ev;
        ev.playerId = joining.getPlayerId();
        Gen::EventManager::instance().publish(ev);
    }
    return {};
}

/*-----------------------------------------------------------*//**

Places the bet on the table.

If the bet passes table rules it is placed on the table.

It is an error if the same bet name already exists for this player.
Use setContractAmount() or setOddsAmount() if you need to change the
bet amount or odds.

@param[in] pBet
    the bet of interest
@param[in,out] ep
    if error, ep has the reason
@return
    Success if accepted, otherwise Fail and ep has the reason
*/
Gen::ReturnCode
CrapsTable::addBet(BetPtr pBet, Gen::ErrorPass& ep)
{
    if (fifBetPtrNull(pBet, "addBet()", ep)) return Gen::ReturnCode::Fail;
    if (!betAllowed(*pBet, ep))              return Gen::ReturnCode::Fail;

    tableBets_[static_cast<size_t>(pBet->betName())].push_back(pBet);

    D(pBet->logBet("CrapsTable::addBet()");)

    sendEventBetMade(*pBet);
    sendEventTableBetsChanged();

    return Gen::ReturnCode::Success;
}

//----------------------------------------------------------------

bool
CrapsTable::betAllowed(CrapsBet& bet, Gen::ErrorPass& ep) const
{
    // fif prefix means "fault if"

    if (fifBettingClosed     (bet, 1, ep))                       return false;
    if (fifMissingPlayer     (bet, ep))                          return false;
    if (fifHaveBet           (bet, ep))                          return false;
    if (fifZeroAmount        (bet, bet.contractAmount(), 1, ep)) return false;
    if (fifComeDisallowed    (bet, ep))                          return false;
    if (fifDontPassDisallowed(bet, ep))                          return false;
    if (fifBadMinMaxLineBets (bet, bet.contractAmount(), 1, ep)) return false;
    if (fifBadMinMaxSideBets (bet, bet.contractAmount(), 1, ep)) return false;
    if (fifBadMultiples      (bet, bet.contractAmount(), 1, ep)) return false;

    if (bet.betName() == BetName::PassLine && point_ != 0)
    {
        // Player made PassLine bet after point already established.
        // Silently coerce the pivot to agree with the point.
        bet.setPivotInternal(point_);
    }
    return true;
}

//----------------------------------------------------------------

bool
CrapsTable::isBetAllowed(BetName betName, std::string& diag) const
{
    const auto& bets = EnumBetName::enumerators;
    if (std::find(bets.begin(), bets.end(), betName) == bets.end())
    {
        diag = "Invalid bet name.";
        return false;
    }

    const auto name = EnumBetName::toString(betName);

    if (point_ == 0 &&
        (betName == BetName::Come || betName == BetName::DontCome))
    {
        const auto alternative =
            betName == BetName::Come ? "Pass line" : "Dont Pass";

        diag = fmt::format(
            "{} bet is not allowed on come out roll. Use {} bet instead.",
            name, alternative);
        return false;
    }

    if (point_ != 0 && betName == BetName::DontPass)
    {
        diag = fmt::format(
            "{} bet is not allowed on after established point. "
            "Use Dont Come bet instead.", name);
        return false;
    }

    return true;
}

//----------------------------------------------------------------

bool
CrapsTable::isBetRemovable(BetPtr pBet) const
{
    if (pBet == nullptr) return false;
    if (!haveBet(pBet->betId())) return false;
    if ((pBet->distance() > 0))
    {
        if (pBet->betName() == BetName::PassLine ||
            pBet->betName() == BetName::Come)
        {
            return false;
        }
    }
    return true;
}

/*-----------------------------------------------------------*//**

Removes the bet from the table subject to craps table rules.

If successful, it is expected that Player recovers the bet amount back
into their wallet.

@param[in,out] pBet
    The bet of interest.

@param[in,out] ep
    Holds reason for error

@return
    Success if bet is removed, otherwise Fail and ep has reason.
*/
Gen::ReturnCode
CrapsTable::removeBet(BetPtr pBet, Gen::ErrorPass& ep)
{
    if (fifBetPtrNull(pBet, "removeBet()", ep)) return Gen::ReturnCode::Fail;
    if (fifMissingBet(*pBet, 4, ep))            return Gen::ReturnCode::Fail;
    if (fifBetMustRemain(pBet, ep))             return Gen::ReturnCode::Fail;

    tableBets_[static_cast<size_t>(pBet->betName())].remove(pBet);
    sendEventBetRemoved(*pBet);
    sendEventTableBetsChanged();

    // No adjustment to bank is needed. Bet is just sitting
    // on the table, not using any house money.
    
    return Gen::ReturnCode::Success;
}

/*-----------------------------------------------------------*//**

Removes the bet from the table regardless of craps table rules.

Funds associated with the bet are NOT claimed by the house bank. It is
expected that Player recovers the bet amount into their wallet.  This is
meant to be called upon program shutdown or when player switches table
and the player is allowed to recover their bets instead of abandoning
them.

@param[in,out] pBet
    The bet of interest.
*/
void
CrapsTable::removeBetForce(BetPtr pBet)
{
    if (pBet == nullptr || !haveBet(pBet->betId()))
    {
        LOG_ERROR("CrapsTable::removeBetForce() pBet is null or "
                  "the bet was not found. Player and CrapsTable "
                  "are out of sync.");
        return;
    }
    tableBets_[static_cast<size_t>(pBet->betName())].remove(pBet);
    sendEventBetRemoved(*pBet);
    sendEventTableBetsChanged();
}

/*-----------------------------------------------------------*//**

Changes the contract amount of a bet on the table.

@li The bet must already exist on the table.
@li Overwrites the previous amount.
@li Validates the change against table rules.

@param[in,out] pBet
    The bet of interest.

@param[in] newAmount
    Sets the contract bet amount to newAmount

@param[in,out] ep
    Holds reason for error

@return
    Success if amount has been changed, otherwise Fail and ep has reason

@internal
@li fif prefix means "fault if"
@li Sca suffix means "set contract amount"
@li 2 is the index to select the right diagPrefix
*/
Gen::ReturnCode
CrapsTable::setContractAmount(BetPtr pBet,
                              Gen::Money newAmount,
                              Gen::ErrorPass& ep)
{
    if (fifBetPtrNull(pBet, "setContractAmount()", ep)) return Gen::ReturnCode::Fail;
    if (fifBettingClosed    (*pBet, 2, ep))             return Gen::ReturnCode::Fail;
    if (fifMissingBet       (*pBet, 2, ep))             return Gen::ReturnCode::Fail;
    if (fifZeroAmount       (*pBet, newAmount, 2, ep))  return Gen::ReturnCode::Fail;
    if (fifBadPassLineChange(*pBet, newAmount, 2, ep))  return Gen::ReturnCode::Fail;
    if (fifBadDontPassChange(*pBet, newAmount, 2, ep))  return Gen::ReturnCode::Fail;
    if (fifBadMinMaxLineBets(*pBet, newAmount, 2, ep))  return Gen::ReturnCode::Fail;
    if (fifBadMinMaxSideBets(*pBet, newAmount, 2, ep))  return Gen::ReturnCode::Fail;
    if (fifBadMultiples     (*pBet, newAmount, 2, ep))  return Gen::ReturnCode::Fail;

    pBet->setContractAmountInternal(newAmount);

    D(pBet->logBet("CrapsTable::setContractAmount()");)

    sendEventBetChanged(*pBet);
    sendEventTableBetsChanged();
    
    return Gen::ReturnCode::Success;
}

/*-----------------------------------------------------------*//**

Sets, changes, or removes the amount for an odds bet.

Overwrites the previous amount, if any. A value
of zero removes it altogether.

It is only permissable to set an odds amount if the following
conditions are true:

@li the bet is already on the table
@li the bet is a PassLine, DontPass, Come, or DontCome bet
@li the bet has an assigned pivot (point) (i.e, pivot is non-zero)
@li the new amount is subject to table limits min/max odds

@param[in,out] pBet
    The bet of interest.

@param[in] oddsAmount
    The amount to set it to. Clobbers any previous setting.

@param[in,out] ep
    Holds reason for error

@returns
    Success if the bet was accepted, otherwise Fail and ep has
    the reason.

@internal
    diagnostic messages look like this:
    CrapsBet::setOddsAmount(): Unable to set odds bet; bet(betId:157, betName:DontPass(4)). Odds bet amount of $1 is too small. Minimum odds for this bet is 2.
    CrapsBet::setOddsAmount(): Unable to set odds bet; bet(betId:159, betName:DontPass(6)). Exceeds table limit of 5x odds; Contract amount is $1 which allows max odds amount of $5.
*/
Gen::ReturnCode
CrapsTable::setOddsAmount(BetPtr pBet,
                          Gen::Money oddsAmount,
                          Gen::ErrorPass& ep)
{
    if (fifBetPtrNull(pBet, "setOddsAmount()", ep))  return Gen::ReturnCode::Fail;
    if (fifBettingClosed    (*pBet, 3, ep))          return Gen::ReturnCode::Fail;
    if (fifMissingBet       (*pBet, 3, ep))          return Gen::ReturnCode::Fail;
    if (fifBadBetTypeForOdds(*pBet, ep))             return Gen::ReturnCode::Fail;
    if (fifZeroPivotForOdds (*pBet, ep))             return Gen::ReturnCode::Fail;
    if (fifBadMinMaxForOdds (*pBet, oddsAmount, ep)) return Gen::ReturnCode::Fail;

    pBet->setOddsAmountInternal(oddsAmount);

    D(pBet->logBet("CrapsTable::setOddsAmount()");)
        
    sendEventBetChanged(*pBet);
    sendEventTableBetsChanged();

    return Gen::ReturnCode::Success;
}

//----------------------------------------------------------------
//
// Returns shared_ptr to the bet of interest.
//
BetPtr
CrapsTable::getBet(const BetId& betId, Gen::ErrorPass& ep) const
{
    auto pBet = findBetById(betId);
    if (pBet == nullptr)
    {
        ep.setDescription("CrapsTable::getBet(): no such betId: " +
                          std::to_string(betId) + ".");
    }
    return pBet;
}

//----------------------------------------------------------------
//
// Determine if we have the given bet on the table.
//
bool
CrapsTable::haveBet(const BetId& betId) const
{
    return findBetById(betId) != nullptr;
}

//----------------------------------------------------------------
//
// Find a bet by ID.
//
BetPtr
CrapsTable::findBetById(const BetId& betId) const
{
    // Loop over all bets
    for (size_t i = 0; i < tableBets_.size(); ++i)
    {
        auto& bets = tableBets_[i];
        for (auto& b : bets)
        {
            if (betId == b->betId())
            {
                return b;
            }
        }
    }
    return nullptr;
}

//----------------------------------------------------------------

void
CrapsTable::rollDice()
{
    declareBettingClosed();
    throwDice();
    if (!resolveBets())
    {
        // Do not advance the point or dispense partial results. The failure
        // is logged and published as UslBetEvaluationFailed.
        declareBettingOpen();
        return;
    }
    advanceState();            // Updates point, updates shooter
    bumpRecentRolls(dice_);
    currentStats_.recordDiceRoll(point_, dice_);
    lastRollStats_.rollCount = getNumRolls();
    declareBettingOpen();
}

//----------------------------------------------------------------

void
CrapsTable::declareBettingClosed()
{
    bettingOpen_ = false;
    Gen::EventManager::instance().publish(Ctrl::UslBettingClosed{});

    lastRollStats_.prep(getAmountOnTable(), getNumBetsOnTable());
    for (auto p : players_)
    {
        p->bettingClosed();
    }
}

//----------------------------------------------------------------

void
CrapsTable::declareBettingOpen()
{
    bettingOpen_ = true;
    Gen::EventManager::instance().publish(Ctrl::UslBettingOpened{});
}

//----------------------------------------------------------------

void
CrapsTable::throwDice()
{
    if (isTestRoll_) dice_ = testRollDice_; else dice_.roll();
    sendEventDiceThrowStart();
    sendEventDiceNewValue();
}

//----------------------------------------------------------------
//
// Update point, update shooter, update stats
//
void
CrapsTable::advanceState()
{
    if (point_ == 0) // come out roll
    {
        if (CrapsBet::pointNums_.contains(dice_.value()))
        {
            point_ = dice_.value();
            Ctrl::UslPointEstablished ev; ev.point = point_;
            Gen::EventManager::instance().publish(ev);
        }
    }
    else if (dice_.value() == 7)
    {
        point_ = 0;
        Gen::EventManager::instance().publish(Ctrl::UslSevenOut{});
        advanceShooter();
    }
    else if (point_ == dice_.value())
    {
        point_ = 0;
        Gen::EventManager::instance().publish(Ctrl::UslPassLineWinner{});
    }
}

//----------------------------------------------------------------

void
CrapsTable::advanceShooter()
{
    if (players_.empty())
    {
        assert(false);
        return;
    }

    Player* prev = pCurrentShooter_;

    auto it = std::find(players_.begin(), players_.end(), pCurrentShooter_);

    if (it == players_.end())
    {
        // This should never happen: pCurrentShooter_ must be in players_.
        LOG_ERROR("CrapsTable::advanceShooter(): current shooter "
                  "not found. Should never happen");
        return;
    }

    ++it;

    if (it == players_.end())
        it = players_.begin();

    pCurrentShooter_ = *it;

    if (pCurrentShooter_ != prev)
    {
        Ctrl::UslNewShooter ev;
        ev.playerId = pCurrentShooter_->getPlayerId();
        Gen::EventManager::instance().publish(ev);
    }
}

//----------------------------------------------------------------

bool
CrapsTable::resolveBets()
{
    Gen::EventManager::instance().publish(Ctrl::UslResolveBetsStart{});
    if (!evaluateBets())
    {
        // No player or house accounting has run yet. Discard every decision
        // so a failed evaluation cannot partially settle the table.
        clearDrl();
        sendEventTableResolveBetsEnd();
        return false;
    }
    dispenseResults();
    trimTableBets();
    clearDrl();
    
    sendEventTableResolveBetsEnd();
    sendEventTableBetsChanged();
    sendEventTableLastRollStatsChanged();
    sendEventTableSessionStatsChanged();
    return true;
}

//----------------------------------------------------------------
//
// Visit each bet on the table for a decsion.
//
// Upon returning, the decision results list (DRL) is populated.
//
bool
CrapsTable::evaluateBets()
{
    assert(drl_.empty());
    for (size_t i = 0; i < tableBets_.size(); ++i)
    {
        auto& bets = tableBets_[i];
        for (auto& b : bets)
        {
            if (!evalOneBet(*b)) return false;
        }
    }
    return true;
}

//----------------------------------------------------------------
//
// Creates a decision record for the given bet and adds it to the DRL.
//
bool
CrapsTable::evalOneBet(CrapsBet& bet)
{
    DecisionRecord dr;
    Gen::ErrorPass ep;

    if (bet.evaluate(point_, dice_, rules_, dr, ep) == Gen::ReturnCode::Success)
    {
        drl_.push_back(dr);
        return true;
    }

    ep.prepend("CrapsTable::evalOneBet() ");
    sendEventBetEvaluationFailed(bet, ep.fullDesc());
    return false;
}

//----------------------------------------------------------------
//
// Inform Players and Bank of results.
//
// Update dice roll stats here, while decision list is available.
//
void
CrapsTable::dispenseResults()
{
    disburseHouseResults();
    disbursePlayerWins();
    disbursePlayerLoses();
    disbursePlayerKeeps();
    disburseDone();
}

//----------------------------------------------------------------

void
CrapsTable::disburseHouseResults()
{
    bool changed = false;

    for (const auto& r : drl_)
    {
        // World is one aggregate wager in the model, but its five components
        // settle separately. The player-side win is the net profit after the
        // four losing components; the bank must still record those component
        // losses and pay the winning component's gross profit. This also
        // handles a 7, where the net profit is zero but $4 is won and paid.
        if (r.pBet != nullptr && r.pBet->betName() == BetName::World &&
            r.decision && r.lose == 0)
        {
            const Gen::Money component = r.pBet->contractAmount() / 5;
            const Gen::Money losingComponents =
                r.pBet->contractAmount() - component;
            const Gen::Money grossComponentProfit = r.win + losingComponents;
            if (losingComponents > 0)
            {
                houseBank_.deposit(losingComponents);
                lastRollStats_.amountWin += losingComponents;
                lastRollStats_.numBetsWin++;
            }
            if (grossComponentProfit > 0)
            {
                houseBank_.withdraw(grossComponentProfit);
                lastRollStats_.amountLose += grossComponentProfit;
                lastRollStats_.numBetsLose++;
            }
            changed = true;
            continue;
        }

        if (r.lose > 0)  // player loses, house wins
        {
            changed = true;
            houseBank_.deposit(r.lose);
            lastRollStats_.amountWin += r.lose;
            lastRollStats_.numBetsWin++;
        }
        if (r.win > 0)  // player wins, house loses
        {
            changed = true;
            // r.win is net of commission. Withdraw gross winnings, then
            // credit the commission below, so the bank's net change equals
            // the amount actually paid to the player.
            houseBank_.withdraw(r.win + r.commission);
            lastRollStats_.amountLose += r.win;
            lastRollStats_.numBetsLose++;
        }
        if (r.commission > 0)
        {
            houseBank_.deposit(r.commission);
        }
    }
    if (changed)
    {
        sendEventTableBalanceChanged();
    }
}

//----------------------------------------------------------------

void
CrapsTable::disbursePlayerWins()
{
    for (const auto& r : drl_)
    {
        if (r.win > 0 ||
            (r.pBet != nullptr && r.pBet->betName() == BetName::World &&
             r.decision && r.lose == 0))
        {
            r.pBet->player().processWin(r);
            currentStats_.recordWin(*(r.pBet), r.win);
        }
    }
}

//----------------------------------------------------------------

void
CrapsTable::disbursePlayerLoses()
{
    for (const auto& r : drl_)
    {
        if (r.lose > 0)
        {
            r.pBet->player().processLose(r);
            currentStats_.recordLose(*(r.pBet), r.lose);
        }
    }
}

//----------------------------------------------------------------

void
CrapsTable::disbursePlayerKeeps()
{
    for (const auto& r : drl_)
    {
        if (!r.decision)
        {
            r.pBet->player().processKeep(r);
            currentStats_.recordKeep(*(r.pBet));
        }
    }
}

//----------------------------------------------------------------
//
// Tell each player dispensing money is done.
//
// Allows players to close out their last roll stats. Can't use events
// for this as asynchronous events arrive after bets have already been
// removed.
//
void
CrapsTable::disburseDone()
{
    for (auto p : players_)
    {
        p->disburseDone();
    }
}

//----------------------------------------------------------------
//
// Remove bets whose resolved outcome ends the wager.
//
// A win can be resolved while a Place/Buy/Lay/Hardway wager remains active.
// Only trim after dispensing results. Need the bet object in-scope
// when player processes a decision record. A player implementation
// might not be holding their bet pointers, yet still want to access
// the bet. It should be valid for player to lookup bet by id while
// player is processing decision record.
//
void
CrapsTable::trimTableBets()
{
    for (const auto& dr : drl_)
    {
        if (!dr.removeBet) continue;

        for (size_t i = 0; i < tableBets_.size(); ++i)
        {
            auto& bets = tableBets_[i];
            if (removeMatchingBet(bets, dr.pBet))
            {
                break;
            }
        }
    }
}

//----------------------------------------------------------------
//
// Part of trimTableBets processing chain.
//
bool
CrapsTable::removeMatchingBet(BetList& bets, CrapsBet* pBet)
{
    auto it = std::find_if(bets.begin(), bets.end(),
        [pBet](const BetPtr& b)
        {
            return b.get() == pBet;
        });

    if (it != bets.end())
    {
        sendEventBetRemoved(**it);
        bets.erase(it);
        return true;
    }
    return false;
}

//----------------------------------------------------------------
//
// Administrative function to clear out all bets owned by
// a player because he left the table. Money for each bet found
// is given to the house, as would occur in a real craps grame.
//
void
CrapsTable::removePlayerBets(Player* pPlayer)
{
    for (size_t i = 0; i < tableBets_.size(); ++i)
    {
        removeBetsByPlayerPtr(tableBets_[i], pPlayer);
    }
}

//----------------------------------------------------------------
//
// Part 2 of removePlayerBets, this part traverses the
// std::list of bets and removes bet if it matches playerId.
// Claims bet money for the house bank.
//
void
CrapsTable::removeBetsByPlayerPtr(BetList& bets, Player* pPlayer)
{
    for (auto it = bets.begin(); it != bets.end(); )
    {
        if (*it && (*it)->pPlayer_ == pPlayer)
        {
            BetPtr p = *it;
            houseBank_.deposit(p->contractAmount());
            houseBank_.deposit(p->oddsAmount());
            sendEventBetRemoved(*p);
            it = bets.erase(it);
        }
        else
        {
            ++it;
        }
    }
}

//----------------------------------------------------------------
//
// Zero out decision result list.
//
void
CrapsTable::clearDrl()
{
    drl_.clear();
}

//----------------------------------------------------------------

bool
CrapsTable::havePlayer(const Player* pPlayer) const
{
    return std::find(players_.begin(), players_.end(), pPlayer) != players_.end();
}

//----------------------------------------------------------------

void
CrapsTable::removePlayerByPtr(Player* pPlayer)
{
    auto it = std::find(players_.begin(), players_.end(), pPlayer);
    if (it != players_.end())
    {
        players_.erase(it);
    }
}

//----------------------------------------------------------------

void
CrapsTable::resetStats()
{
    recentRolls_.clear();
    currentStats_.reset();
    houseBank_.resetStats();
}

//----------------------------------------------------------------

std::vector<Player*>
CrapsTable::getPlayers() const
{
    std::vector<Player*> v;
    for (const auto pPlayer : players_)
    {
        v.push_back(pPlayer);
    }
    return v;
}

//----------------------------------------------------------------

unsigned
CrapsTable::getNumPlayers() const
{
    return players_.size();
}

//----------------------------------------------------------------

const TableId&
CrapsTable::getTableId() const
{
    return tableId_;
}

//----------------------------------------------------------------

const std::string&
CrapsTable::getTableName() const
{
    return tableName_;
}

//----------------------------------------------------------------
//
// Returns current point, or 0 if in come-out
//
unsigned
CrapsTable::getPoint() const
{
    return point_;
}

//----------------------------------------------------------------

Player*
CrapsTable::getCurrentShooter() const
{
    return pCurrentShooter_;
}

//----------------------------------------------------------------

Dice
CrapsTable::getCurrentRoll() const
{
    return dice_;
}

//----------------------------------------------------------------

unsigned
CrapsTable::getNumRolls() const
{
    return dice_.rollCount();
}

//----------------------------------------------------------------

unsigned
CrapsTable::getMinLineBet() const
{
    return rules_.wagerLimit(BetName::PassLine).minimum;
}

//----------------------------------------------------------------

unsigned
CrapsTable::getMaxLineBet() const
{
    return rules_.wagerLimit(BetName::PassLine).maximum;
}

//----------------------------------------------------------------

unsigned
CrapsTable::getMaxOdds() const
{
    return rules_.odds.flatMultiplier;
}

//----------------------------------------------------------------

const TableRules&
CrapsTable::getTableRules() const
{
    return rules_;
}

//----------------------------------------------------------------

Gen::Money
CrapsTable::placementCommission(const CrapsBet& bet, Gen::Money contractAmount) const
{
    const TableRules::Commission* commission = nullptr;
    if (bet.betName() == BetName::Buy)
        commission = &rules_.buyCommission;
    else if (bet.betName() == BetName::Lay)
        commission = &rules_.layCommission;

    if (commission == nullptr ||
        commission->collection != TableRules::CommissionCollection::OnPlacement)
        return 0;

    const std::uint64_t raw =
        static_cast<std::uint64_t>(contractAmount) * commission->basisPoints;
    Gen::Money amount = static_cast<Gen::Money>(raw / 10000);
    if (commission->rounding == TableRules::PayoutRounding::Down &&
        commission->roundingUnit > 1)
        amount = (amount / commission->roundingUnit) * commission->roundingUnit;
    if (contractAmount > 0 && amount < commission->minimum)
        amount = commission->minimum;
    return amount;
}

//----------------------------------------------------------------

void
CrapsTable::collectPlacementCommission(CrapsBet& bet, Gen::Money amount)
{
    if (amount <= 0) return;
    houseBank_.deposit(amount);
    bet.setPlacementCommissionInternal(amount);
    sendEventTableBalanceChanged();
}

//----------------------------------------------------------------

void
CrapsTable::refundPlacementCommission(CrapsBet& bet)
{
    const Gen::Money amount = bet.placementCommission();
    if (amount <= 0) return;
    houseBank_.withdraw(amount);
    bet.setPlacementCommissionInternal(0);
    sendEventTableBalanceChanged();
}

//----------------------------------------------------------------
//
// Gets today's running session balance. Always +/- starting from 0.
//
int
CrapsTable::getBalance() const
{
    return houseBank_.getAmtDeposited() - houseBank_.getAmtWithdrawn();
}

//----------------------------------------------------------------

const RecentRolls&
CrapsTable::getRecentRolls() const
{
    return recentRolls_;
}

//----------------------------------------------------------------
//
// Returns number of bets currently on the table.
//
unsigned
CrapsTable::getNumBetsOnTable() const
{
    unsigned num = 0;
    // Vist each list of bets
    for (size_t i = 0; i < tableBets_.size(); ++i)
    {
        auto& bets = tableBets_[i];
        num += bets.size();
    }
    return num;
}

//----------------------------------------------------------------
//
// Returns the amount of money currently bet on the table.
//
Gen::Money
CrapsTable::getAmountOnTable() const
{
    unsigned amount = 0;
    // Vist each list of bets
    for (size_t i = 0; i < tableBets_.size(); ++i)
    {
        auto& bets = tableBets_[i];
        for (auto& b : bets)
        {
            amount += b->contractAmount() + b->oddsAmount();
        }
    }
    return amount;
}

/*-----------------------------------------------------------*//**

Returns read-only access to current session table stats.

@return current session table stats (read-only)

*/
const TableStats&
CrapsTable::getCurrentStats() const
{
    return currentStats_;
}

/*-----------------------------------------------------------*//**

Returns read-only access to all-time stats.

All-time stats are an aggregation of all sessions played on this table.

Note that all-time stats are only updated when the current session ends.

@return all-time table stats (read-only)

*/
const TableStats&
CrapsTable::getAlltimeStats() const
{
    return alltimeStats_;
}

//----------------------------------------------------------------

const BankStats&
CrapsTable::getBankCurrentStats() const
{
    return houseBank_.getCurrentStats();
}

//----------------------------------------------------------------

const BankStats&
CrapsTable::getBankAlltimeStats() const
{
    return houseBank_.getAlltimeStats();
}

//----------------------------------------------------------------

const LastRollStats&
CrapsTable::getLastRollStats() const
{
    return lastRollStats_;
}

//----------------------------------------------------------------
//
// Return session history.
//
// This is just a relay function for convenience.
//
const SessionHistory::Sessions&
CrapsTable::getSessionHistory() const
{
    return alltimeStats_.sessionHistory.getSessions();
}

//----------------------------------------------------------------

bool
CrapsTable::isComeOutRoll() const
{
    return point_ == 0;
}

//----------------------------------------------------------------

bool
CrapsTable::isBettingOpen() const
{
    return bettingOpen_;
}

//-----------------------------------------------------------------

void
CrapsTable::bumpRecentRolls(const Dice& dice)
{
    if (recentRolls_.size() >= config_.maxRecentRolls)
    {
        recentRolls_.pop_front();
    }
    recentRolls_.push_back(dice);
}

//----------------------------------------------------------------

void
CrapsTable::sendEventPlayerJoinedTable(const Player& player) const
{
    Ctrl::UslPlayerJoinedTable ev;
    ev.playerId = player.getPlayerId();
    Gen::EventManager::instance().publish(ev);
}
    
//----------------------------------------------------------------

void
CrapsTable::sendEventPlayerLeftTable(const Player& player) const
{
    Ctrl::UslPlayerLeftTable ev;
    ev.playerId = player.getPlayerId();
    Gen::EventManager::instance().publish(ev);
}

//----------------------------------------------------------------

void
CrapsTable::sendEventTableBalanceChanged() const
{
    Ctrl::UslTableBalanceChanged ev;
    ev.balance    = getBalance();               // balance from session start
    ev.netBalance = houseBank_.getSessionNet(); // profit/loss this session
    Gen::EventManager::instance().publish(ev);
}

//----------------------------------------------------------------

void
CrapsTable::sendEventBetMade(const CrapsBet& bet) const
{
    Ctrl::UslBetMade ev;
    ev.playerId       = bet.player().getPlayerId();
    ev.betId          = bet.betId();
    ev.betName        = bet.betName();
    ev.contractAmount = bet.contractAmount();
    ev.oddsAmount     = bet.oddsAmount();
    ev.pivot          = bet.pivot();

    Gen::EventManager::instance().publish(ev);
}

//----------------------------------------------------------------

void
CrapsTable::sendEventBetRemoved(const CrapsBet& bet) const
{
    Ctrl::UslBetRemoved ev;
    ev.playerId = bet.player().getPlayerId();
    ev.betId = bet.betId();
    ev.betName = bet.betName();
    Gen::EventManager::instance().publish(ev);
}

//----------------------------------------------------------------

void
CrapsTable::sendEventBetChanged(const CrapsBet& bet) const
{
    Ctrl::UslBetChanged ev;
    
    ev.playerId       = bet.player().getPlayerId();
    ev.betId          = bet.betId();
    ev.betName        = bet.betName();
    ev.contractAmount = bet.contractAmount();
    ev.oddsAmount     = bet.oddsAmount();
    ev.pivot          = bet.pivot();

    Gen::EventManager::instance().publish(ev);
}

//----------------------------------------------------------------

void
CrapsTable::sendEventDiceThrowStart() const
{
    Ctrl::UslDiceThrowStart ev;
    ev.rollCount = dice_.rollCount();
    Gen::EventManager::instance().publish(ev);
}

//----------------------------------------------------------------

void
CrapsTable::sendEventDiceNewValue() const
{
    Ctrl::UslDiceNewValue ev;
    ev.rollCount = dice_.rollCount();
    ev.val       = dice_.value();
    ev.d1        = dice_.d1();
    ev.d2        = dice_.d2();
    Gen::EventManager::instance().publish(ev);
    LOG_DEBUG("CrapsTable() roll dice; " + dice_.toString());
}

//----------------------------------------------------------------

void        
CrapsTable::sendEventTableResolveBetsEnd() const
{
    Gen::EventManager::instance().publish(Ctrl::UslResolveBetsEnd{});
}

//----------------------------------------------------------------

void        
CrapsTable::sendEventTableSessionStatsChanged() const
{
    Ctrl::UslTableSessionStatsChanged ev;
    ev.numBetsWon  = currentStats_.betStats.totNumLoseAllBets;
    ev.numBetsLost = currentStats_.betStats.totNumWinsAllBets;
    Gen::EventManager::instance().publish(ev);
}

//----------------------------------------------------------------

void        
CrapsTable::sendEventTableLastRollStatsChanged() const
{
    Ctrl::UslTableLastRollStatsChanged lrs{};
    lrs.stats = lastRollStats_;
    Gen::EventManager::instance().publish(lrs);
}

//----------------------------------------------------------------

void
CrapsTable::sendEventTableBetsChanged() const
{
    Ctrl::UslTableBetsChanged ev;
    ev.numBetsOnTable = getNumBetsOnTable();
    ev.amountOnTable  = getAmountOnTable();
    
    Gen::EventManager::instance().publish(ev);
}

//----------------------------------------------------------------

void
CrapsTable::sendEventBetEvaluationFailed(const CrapsBet& bet,
                                         const std::string& diag) const
{
    LOG_ERROR(diag);
    Ctrl::UslBetEvaluationFailed ev;
    ev.playerId    = bet.player().getPlayerId();
    ev.betId       = bet.betId();
    ev.betName     = bet.betName();
    ev.description = diag;

    Gen::EventManager::instance().publish(ev);
}

//----------------------------------------------------------------

















//----------------------------------------------------------------
//
// Shows various ways to walk tableBets_
//
#if 0
void
CrapsTable::resolveBetsOld()
{
    CrapsBet bet("Player1", BetName::Passine, 100, 0);
    // Gbl::pPlayerMgr->processDecision(dr);
    unsigned point = 4;
    // dice.roll();
    Dice dice; dice.set(2,2);

    DecisionRecord dr;
    Gen::ErrorPass ep;
    if (bet.evaluate(point, dice, dr, ep) == Gen::ReturnCode::Success)
    {
        std::cout << dr << std::endl;
    }
    else
    {
        std::cout << ep.description() << std::endl;
    }

    // Process all bets
    for (size_t i = 0; i < static_cast<size_t>(BetName::Count); ++i)
    {
        auto& bets = tableBets_[i];
        for (auto& b : bets)
        {
            b->pivot();
        }
    }

    // Process all bets
    for (size_t i = 0; i < tableBets_.size(); ++i)
    {
        auto& bets = tableBets_[i];
        for (auto& b : bets)
        {
            b->pivot();
        }
    }

    // Process all bets
    for (auto name : EnumBetName::enumerators)
    {
        auto& bets = tableBets_[static_cast<size_t>(name)];
        for (auto& b : bets)
        {
            b->pivot();
        }
    }

    // Process all Place bets
    for (auto& b : tableBets_[PlaceBetIndex])
    {
        b->pivot();
    }
}
#endif

//----------------------------------------------------------------
//
// Shows how to load yaml config from strings
//
// loadFromStrings
//
#if 0

#include <yaml-cpp/yaml.h>
#include <string>

int main() {
    std::string input = R"(
config:
  level: debug
  retries: 3
  enabled: true
)";

    YAML::Node root = YAML::Load(input);

    std::cout << "Level: " << root["config"]["level"].as<std::string>() << "\n";
    std::cout << "Retries: " << root["config"]["retries"].as<int>() << "\n";
    std::cout << "Enabled: " << root["config"]["enabled"].as<bool>() << "\n";
}

TEST_CASE("Config loads correctly from string") {
    std::string yaml = R"(
db:
  host: localhost
  port: 5432
)";
    YAML::Node root = YAML::Load(yaml);
    REQUIRE(root["db"]["port"].as<int>() == 5432);
}

// Build it programmatically
YAML::Node node;
node["name"] = "craps";
node["version"] = 1.0;

std::cout << node << "\n";


#endif



#if 0

// old

//----------------------------------------------------------------
//
// Determine if we have the given bet on the table.
//
bool
CrapsTable::haveBet(const BetPtr bet) const
{
    return findBetById(bet->betId()) != nullptr;

    // Loop over all bets
    for (size_t i = 0; i < tableBets_.size(); ++i)
    {
        auto& bets = tableBets_[i];
        auto it = std::find(bets.begin(), bets.end(), bet);
        if (it != bets.end())
        {
            return true;
        }
    }
    return false;
}

//----------------------------------------------------------------
//
// Determine if we already have the given bet on the table.
//
bool
CrapsTable::haveBet(const PlayerId& playerId, BetName betName,
                    unsigned pivot) const
{
    auto& bets = tableBets_[static_cast<size_t>(betName)];
    for (auto& b : bets)
    {
        if (playerId == b->playerId() &&
            betName  == b->betName()  &&
            pivot    == b->pivot())
        {
            return true;
        }
    }
    return false;
}


//----------------------------------------------------------------
//
// Determine if we have the given bet on the table.
//
bool
CrapsTable::haveBet(const CrapsBet& bet) const
{
    // Loop over all bets
    for (size_t i = 0; i < tableBets_.size(); ++i)
    {
        auto& bets = tableBets_[i];
        auto it = std::find(bets.begin(), bets.end(), bet);
        if (it != bets.end())
        {
            return true;
        }
    }
    return false;
}

#endif
