//----------------------------------------------------------------
//
// File: Player.cpp
//
//----------------------------------------------------------------

#include <craps/Player.h>
#include <craps/CrapsTable.h>
#include <craps/DecisionRecord.h>
#include <controller/GameEvents.h>
#include <gen/EventManager.h>
#include <gen/Logger.h>
#include <gen/Uuid.h>
#include <fmt/format.h>
#include <cassert>

using namespace Craps;

//----------------------------------------------------------------
//
// Constructor.
//
Player::Player(const PlayerId& playerId)
    : playerId_(playerId)
    , wallet_(InitialStartingBankBalance_, RefillThreshold_, RefillAmount_)
{
}

//----------------------------------------------------------------
//
// Will create a fresh PlayerId
//
Player*
Player::createPlayer(const std::string& playerName)
{
    Player* p = new Player(Gen::generateUuid());
    p->setName(playerName);
    return p;
}

/*-----------------------------------------------------------*//**

Construct Player from in-memory YAML text.

The text is the Player's own state, the same thing toYAML() produces.
Throws upon error.

Static function.
*/
Player*
Player::fromString(const std::string& yaml,
                   const PlayerId&    playerId)
{
    std::unique_ptr<Player> p(new Player(playerId));
    YAML::Node root = YAML::Load(yaml);
    p->fromYAML(root);                    // throws
    return p.release();
}

//----------------------------------------------------------------
//
// Convert Player to YAML
//
YAML::Node
Player::toYAML() const
{
    YAML::Node node;
    node["playerId"]         = playerId_;
    node["playerName"]       = playerName_;
    node["shortDescription"] = shortDescription_;
    node["fullDescription"]  = fullDescription_;
    node["Bank"]             = wallet_.toYAML();
    alltimeStats_.toYAML(node);
    return node;
}

//----------------------------------------------------------------
//
// Convert YAML to Player
//
void
Player::fromYAML(const YAML::Node& node)
{
    auto playerIdInFile = node["playerId"].as<std::string>();
    playerName_         = node["playerName"].as<std::string>();
    shortDescription_   = node["shortDescription"].as<std::string>();
    fullDescription_    = node["fullDescription"].as<std::string>();

    // YAML playerId must agree with id from ctor
    if (playerIdInFile != playerId_)
    {
        throw std::runtime_error("Player ID mismatch: expected " +
                                 playerId_ + ", found " + playerIdInFile);
    }

    wallet_.fromYAML(node["Bank"]);
    alltimeStats_.fromYAML(node);
}

//----------------------------------------------------------------
//
//  Program is quitting. Same as ending the session.
//
void
Player::shutdown()
{
    endSession();
}

//----------------------------------------------------------------
//
//  Ends the player's session: leaves the table, records the session
//  and merges stats. Writes nothing to disk. The caller persists
//  toYAML() afterward (see PlayerManager::shutdown() and
//  PlayerManager::switchPlayer()).
//
//  Used when the program quits and when the user switches to another
//  player. A player who switched out can join a table again later,
//  see beginNewSession().
//
void
Player::endSession()
{
    (void) leaveTable();

    // Create an entry for today's session.
    alltimeStats_.sessionHistory.addSessionSummary(
        1, // num players
        currentStats_.betStats.totNumBetsAllBets,
        wallet_.getAmtDeposited(),
        wallet_.getAmtWithdrawn());

    // Merge alltime stats with today's session.
    alltimeStats_.merge(currentStats_);
    wallet_.mergeStats();

    sessionEnded_ = true;
}

//----------------------------------------------------------------
//
//  Called when a player who has ended a session joins a table again.
//  Everything counted for the old session was merged into the alltime
//  stats, so start counting afresh. The balance carries over.
//
void
Player::beginNewSession()
{
    currentStats_.reset();
    wallet_.beginNewSession();
    alltimeStats_.sessionHistory.beginNextSession();
    sessionEnded_ = false;
}

//----------------------------------------------------------------

zeus::expected<void, Gen::ErrorPass>
Player::joinTable(CrapsTable& table)
{
    auto result = table.addPlayer(*this);
    if (!result)
    {
        result.error().prepend("Player " + playerName_ +
                               " Unable to join table. ");
        return zeus::unexpected<Gen::ErrorPass>(
            std::move(result).error());
    }

    pTable_ = &table;
    if (sessionEnded_)
    {
        beginNewSession();
    }
    return {};
}

/*-----------------------------------------------------------*//**

Player leaves the table.

Any outstanding bets on the table are forcibly removed, meaning bets
are pulled from the table and funds are returned to the player. This
bypasses normal table checks that prevent removing bets due to Craps
table rules.

UI should perform confirmation checks with users prior to leaving table.

leaveTable() is called upon program shutdown as well as
when player switches tables.

@return
    Success, otherwsie Fail and ep has the reason for failure.
    It is not an error if a player has not joined a table.
*/
zeus::expected<void, Gen::ErrorPass>
Player::leaveTable()
{
    if (pTable_ == nullptr)  // Not joined, so nothing to leave.
    {
        Gen::ErrorPass ep;
        std::string s = "Player " + playerName_ +
            " unable to leave table. Player is not there.";
        EP_SET(ep, En::NotFoundError, Et::ProcessingError,
               Es::Indeterminate, s);
        assert(getNumBetsOnTable() == 0);
        return zeus::unexpected<Gen::ErrorPass>(std::move(ep));
    }

    // Remove any outstanding bets from table, recover funds
    // Manually increment iterator so we can erase while iterating
    for (auto it = bets_.begin(); it != bets_.end(); ) // no increment here
    {
        auto pBet = *it;
        const Gen::Money placementFee = pBet->hasDecision()
            ? 0 : pBet->placementCommission();
        pTable_->removeBetForce(pBet);
        if (placementFee > 0)
            pTable_->refundPlacementCommission(*pBet);
        wallet_.deposit(pBet->contractAmount() + pBet->oddsAmount() + placementFee);
        it = bets_.erase(it); // returns next valid iterator
    }

    auto result = pTable_->removePlayer(*this);
    if (!result)
    {
        result.error().prepend("Failed to leave table. ");
        return zeus::unexpected<Gen::ErrorPass>(std::move(result).error());
    }

    pTable_ = nullptr;  // No longer at a table; bets are refused until we join
    return {};
}

/*-----------------------------------------------------------*//**

Makes a bet on the table.

@param[in] betName
    the type of bet to make

@param[in] contractAmount
    the dollar amount to bet

@param[in] pivot
    The number this bet is focused on. For example a Place bet must set
    the pivot to 4,5,6,8,9 or 10. For PassLine/Come/DontPass/DontCome bets,
    the caller sets the pivot to zero. Zero indicates the pivot number
    needs to be set later. See CrapsBet::CrapsBet() constructor.

@return
    If successful, the shared pointer to the CrapsBet is returned,
    otherwise ErrorPass object has the reason for failure

@internal
@li fif prefix means "fault if"
*/
zeus::expected<BetPtr, Gen::ErrorPass>
Player::makeBet(BetName betName, Gen::Money contractAmount, unsigned pivot)
{
    const std::string fname("Player::makeBet");
    LOG_TRACE(fname + "(" + playerName_ + "): making contract bet");
    
    Gen::ErrorPass ep;
    std::string s = "Unable to make bet(" +
                    std::to_string(contractAmount) +
                    ") for player: " + playerName_ + ". ";

    if (fifNoTable(ep)  ||
        fifInsufficientFunds(nullptr, contractAmount, 0, ep))
    {
        ep.prepend(s);
        LOG_ERROR(fname + "() Error" + ep.fullDesc());
        return zeus::unexpected<Gen::ErrorPass>(std::move(ep));
    }

    auto pBet = makeShared(betName, contractAmount, pivot, ep);
    if (pBet == nullptr)
    {
        ep.prepend(s);
        ep.setErrorType("Betting Error");
        ep.setSeverity(Es::Indeterminate);
        LOG_ERROR(fname + "() Error" + ep.fullDesc());
        return zeus::unexpected<Gen::ErrorPass>(std::move(ep));
    }

    const Gen::Money placementFee = pTable_->placementCommission(*pBet, pBet->contractAmount());
    if (placementFee > 0 &&
        fifInsufficientFunds(nullptr, contractAmount + placementFee, 0, ep))
    {
        ep.prepend(s);
        LOG_ERROR(fname + "() Error" + ep.fullDesc());
        return zeus::unexpected<Gen::ErrorPass>(std::move(ep));
    }
    if (fifBadAddBet(pBet, ep))
    {
        ep.prepend(s);
        ep.setErrorType("Betting Error");
        ep.setSeverity(Es::Indeterminate);
        LOG_ERROR(fname + "() Error" + ep.fullDesc());
        return zeus::unexpected<Gen::ErrorPass>(std::move(ep));
    }

    wallet_.withdraw(contractAmount + placementFee);
    if (placementFee > 0)
        pTable_->collectPlacementCommission(*pBet, placementFee);
    bets_.push_back(pBet);

    sendEventPlayerBalanceChanged();
    sendEventPlayerBetsChanged();
    pBet->logBet(fname + "() Accepted");
    
    return pBet;
}

//----------------------------------------------------------------
//
// Restores a previouly removed bet.
//
// This participates in the undo facility.
//
// Adds the saved previously removed bet back in, bypassing
// validity checks and avoiding double stats counters.
// This only works as part of the undo manager unstacking.
// It does not work for restoring arbitrary bets as no checks
// are made for sufficient funds, duplicates, etc.
//
Gen::ReturnCode
Player::restoreBet(BetPtr pBet, Gen::ErrorPass& ep)
{
    if (pBet == nullptr)
    {
        EP_SET(ep, En::NullPointerError, Et::ProcessingError,
               Es::Indeterminate, "Player::restoreBet(): pBet is nullptr.");
        return Gen::ReturnCode::Fail;
    }
    if (pTable_ == nullptr)
    {
        EP_SET(ep, En::InvalidAccessError, Et::ProcessingError,
               Es::Indeterminate, "Player::restoreBet(): player has not joined a table.");
        return Gen::ReturnCode::Fail;
    }
    const bool feeAlreadyCollected = pBet->placementCommission() > 0;
    const Gen::Money placementFee = feeAlreadyCollected
        ? pBet->placementCommission()
        : (pBet->hasDecision() ? 0 : pTable_->placementCommission(*pBet, pBet->contractAmount()));
    if (pTable_->addBet(pBet, ep) == Gen::ReturnCode::Fail)
    {
        return Gen::ReturnCode::Fail;
    }
    wallet_.withdraw(pBet->contractAmount() + pBet->oddsAmount() +
                     (feeAlreadyCollected ? 0 : placementFee));
    if (!feeAlreadyCollected && placementFee > 0)
        pTable_->collectPlacementCommission(*pBet, placementFee);
    bets_.push_back(pBet);

    sendEventPlayerBetsChanged();
    sendEventPlayerBalanceChanged();
    return Gen::ReturnCode::Success;
}

//----------------------------------------------------------------
//
// Restores a previouly changed bet amount.
//
// This participates in the undo facility.
//
// Adjusts player's wallet due to an undo of a change in bet amount.
//
void
Player::restoreAmounts(BetPtr pBet, const CrapsBet& prevState)
{
    if (pBet == nullptr)
    {
        LOG_ERROR("Player::restoreAmounts(): pBet is nullptr.");
        return;
    }

    auto applyDelta = [this](int delta)
    {
        if (delta > 0)
        {
            // Undoing an increase → get money back
            wallet_.deposit(delta);
        }
        else if (delta < 0)
        {
            // Undoing a decrease → costs us money
            wallet_.withdraw(-delta); // must negate since withdraw expects positive
        }
    };

    int deltaContract = pBet->contractAmount() - prevState.contractAmount();
    applyDelta(deltaContract);

    int deltaOdds = pBet->oddsAmount() - prevState.oddsAmount();
    applyDelta(deltaOdds);

    const Gen::Money currentFee = pBet->placementCommission();
    const Gen::Money previousFee = prevState.placementCommission();
    applyDelta(static_cast<int>(currentFee) - static_cast<int>(previousFee));
    if (currentFee != previousFee && pTable_)
    {
        pTable_->refundPlacementCommission(*pBet);
        if (previousFee > 0)
            pTable_->collectPlacementCommission(*pBet, previousFee);
    }

    sendEventPlayerBalanceChanged();
}

//----------------------------------------------------------------
//
// Purpose of this is to issue std::make_shared in try/catch block.
// Convert exception to ErrorPass.
//
BetPtr
Player::makeShared(BetName betName,
                   Gen::Money contractAmount,
                   unsigned pivot,
                   Gen::ErrorPass& ep)
{
    try
    {
        // CrapsBet ctor can throw.
        return std::make_shared<CrapsBet>(this, betName,
                                          contractAmount, pivot);
    }
    catch(std::invalid_argument& e)
    {
        EP_SET(ep, En::InvalidArgumentError, Et::ProcessingError,
               Es::Major, e.what());
        return nullptr;
    }
}

/*-----------------------------------------------------------*//**

Sets, changes, or removes the amount for an odds bet.

Overwrites the previous amount, if any. A value
of zero removes it altogether.

It is only permissable to set an odds amount if the following
conditions are true:

@li the bet is already on the table
@li the bet is a PassLine, DontPass, Come, or DontCome bet
@li the bet has an assigned pivot (point) (i.e, pivot is non-zero)
@li the new amount is subject to table limits min/max odds

@param[in,out] pBet
    The bet of interest.

@param[in] oddsAmount
    The amount to set it to. Clobbers any previous setting.

@returns
    ErrorPass object if an error occured, otherwise no error.

@internal
@li fif prefix means "fault if"
*/
zeus::expected<void, Gen::ErrorPass>
Player::setOddsAmount(BetPtr pBet, Gen::Money newAmount)
{
    const std::string fname("Player::setOddsAmount()");
    Gen::ErrorPass ep;
    
    // fif prefix means "fault if"

    if (fifMissingBet(pBet, ep)                     ||
        fifNoTable(ep)                              ||
        fifInsufficientFunds(pBet, newAmount, pBet->oddsAmount(), ep))
    {
        ep.prepend("Unable to set odds(" + std::to_string(newAmount) +
            ") for player: " + playerName_ + ". ");
        LOG_ERROR(fname + " Error " + ep.fullDesc());
        return zeus::unexpected<Gen::ErrorPass>(std::move(ep));
    }
    
    Gen::Money saveOddsAmount = pBet->oddsAmount();
    
    wallet_.deposit(pBet->oddsAmount());  // give back old amount, if any
    wallet_.withdraw(newAmount);          // take out new amount
    
    auto rc = pTable_->setOddsAmount(pBet, newAmount, ep);
    if (rc == Gen::ReturnCode::Fail)         // Bet was rejected
    {                                        // Restore prev amount
        wallet_.deposit(newAmount);
        wallet_.withdraw(saveOddsAmount);
        ep.prepend(diagPrefix(2));
        LOG_ERROR(fname + " Error" + ep.fullDesc());
        return zeus::unexpected<Gen::ErrorPass>(std::move(ep));
    }

    sendEventPlayerBetsChanged();
    sendEventPlayerBalanceChanged();
    pBet->logBet(fname + " Accepted");

    return {};
}

/*-----------------------------------------------------------*//**

Changes the contract amount of a bet on the table.

@li The bet must already exist on the table.
@li Validates the change against table rules.
@li Overwrites the previous amount.
@li Fails if insufficient funds.
@li Reclaims funds if reducing contract amount.

@param[in] pBet
    The bet of interest.

@param[in] newAmount
    Sets the contract bet amount to newAmount

@return
    Success if amount has been changed, otherwise Fail and ep has reason

@internal
@li fif prefix means "fault if"
@li 2 is the index to select the right diagPrefix
*/
zeus::expected<void, Gen::ErrorPass>
Player::setContractAmount(
    BetPtr pBet,
    Gen::Money newAmount)
{
    const std::string fname("Player::setContractAmount()");
    Gen::ErrorPass ep;
    
    // fif prefix means "fault if"

    const Gen::Money oldPlacementFee = pBet ? pBet->placementCommission() : 0;
    const Gen::Money newPlacementFee =
        (pBet && pTable_) ? pTable_->placementCommission(*pBet, newAmount) : 0;
    if (fifMissingBet(pBet, ep)                   ||
        fifNoTable(ep)                            ||
        fifInsufficientFunds(pBet, newAmount + newPlacementFee,
                             pBet->contractAmount() + oldPlacementFee, ep))
    {
        ep.prepend("Unable to set contract amount(" + std::to_string(newAmount) +
            ") for player: " + playerName_ + ". ");
        LOG_ERROR(fname + " Error" + ep.fullDesc());
        return zeus::unexpected<Gen::ErrorPass>(std::move(ep));
    }
    
    Gen::Money saveContractAmount = pBet->contractAmount();
    
    wallet_.deposit(saveContractAmount + oldPlacementFee);
    wallet_.withdraw(newAmount + newPlacementFee);
    
    auto rc = pTable_->setContractAmount(pBet, newAmount, ep);
    if (rc == Gen::ReturnCode::Fail)
    {
        wallet_.deposit(newAmount + newPlacementFee);
        wallet_.withdraw(saveContractAmount + oldPlacementFee);
        ep.prepend(diagPrefix(2));
        LOG_ERROR(fname + " Error" + ep.fullDesc());
        return zeus::unexpected<Gen::ErrorPass>(std::move(ep));
    }

    if (oldPlacementFee != newPlacementFee)
    {
        pTable_->refundPlacementCommission(*pBet);
        if (newPlacementFee > 0)
            pTable_->collectPlacementCommission(*pBet, newPlacementFee);
    }
    sendEventPlayerBetsChanged();
    sendEventPlayerBalanceChanged();
    pBet->logBet(fname + " Accepted");

    return {};
}

/*-----------------------------------------------------------*//**

CrapsTable informs us directly (inline) that betting is closed. Can't
use UslBettingClosed or UslDiceThrowStart event since that is
asynchronous and bets will have already have been resolved by the time
we see those events.

*/
void
Player::bettingClosed()
{
    lastRollStats_.prep(getAmountOnTable(), getNumBetsOnTable());
}

/*-----------------------------------------------------------*//**

Process WIN decision

Called by CrapsTable to dish out a winning bet to a Player.

*/
void
Player::processWin(const DecisionRecord& dr)
{
    if (dr.pBet == nullptr ||
        (dr.win <= 0 &&
         !(dr.pBet->betName() == BetName::World && dr.decision && dr.lose == 0)))
    {
        LOG_ERROR("Player::processWin(): invalid DecisionRecord (null bet or non-positive win).");
        return;
    }

    // Confirm we actually own the bet in dr.pBet (raw pointer)
    // Obtain shared_ptr to our bet
    //
    auto pBet = findBetById(dr.pBet->betId());
    if (pBet == nullptr)
    {
        diagBadBetId("processWin() ", dr.pBet->betId());
        assert(false);
        return;
    }

    wallet_.deposit(dr.returnToPlayer);
    if (dr.removeBet)
    {
        // A terminal win returns the original stakes as well as the profit.
        // When returnToPlayer already refunds the odds stake (odds are off
        // during a come-out roll), do not return that same stake a second time.
        const Gen::Money oddsReturnedSeparately =
            (dr.returnToPlayer != 0 &&
             dr.returnToPlayer == pBet->oddsAmount())
                ? pBet->oddsAmount()
                : 0;
        wallet_.deposit(dr.win + pBet->contractAmount() +
                        pBet->oddsAmount() - oddsReturnedSeparately);
    }
    else
    {
        // The wager remains active, so its original stake stays on the table.
        wallet_.deposit(dr.win);
    }

    currentStats_.recordWin(*(dr.pBet), dr.win);
    if (pBet->betName() == BetName::World && dr.decision && dr.lose == 0)
    {
        // The aggregate World bet's net profit hides the component cashflows.
        // Keep Last Roll comparable with the house: record the winning
        // component's gross profit and the four losing component stakes.
        const Gen::Money component = pBet->contractAmount() / 5;
        const Gen::Money losingComponents =
            pBet->contractAmount() - component;
        lastRollStats_.amountWin += dr.win + losingComponents;
        lastRollStats_.amountLose += losingComponents;
    }
    else
    {
        lastRollStats_.amountWin += dr.win;
    }
    lastRollStats_.numBetsWin++;

    sendEventBetResolved(pBet->betName(), pBet->betId(), dr);
    if (dr.removeBet)
    {
        (void) removeBetByPtr(pBet);
    }
}

/*-----------------------------------------------------------*//**

Process LOSE decision

Called by CrapsTable to dish out a losing bet to a Player.

*/
void
Player::processLose(const DecisionRecord& dr)
{
    if (dr.pBet == nullptr || dr.lose <= 0)
    {
        LOG_ERROR("Player::processLose(): invalid DecisionRecord (null bet or non-positive loss).");
        return;
    }

    // Confirm we actually own the bet in dr.pBet (raw pointer)
    // Obtain shared_ptr to our bet
    //
    auto pBet = findBetById(dr.pBet->betId());
    if (pBet == nullptr)
    {
        diagBadBetId("processLose() ", dr.pBet->betId());
        assert(false);
        return;
    }

    // No need to update money. Money was withdrawn from wallet
    // when making the bet. Just deal with return to player, if any.
    //
    wallet_.deposit(dr.returnToPlayer);

    currentStats_.recordLose(*(dr.pBet), dr.lose);
    lastRollStats_.amountLose += dr.lose;
    lastRollStats_.numBetsLose++;

    sendEventBetResolved(pBet->betName(), pBet->betId(), dr);
    (void) removeBetByPtr(pBet);  // Done with this bet
}

/*-----------------------------------------------------------*//**

Process KEEP decision

Called by CrapsTable to inform Player that the current roll of
dice resulted in no decision for the assocated bet.

*/
void
Player::processKeep(const DecisionRecord& dr)
{
    if (dr.pBet == nullptr)
    {
        LOG_ERROR("Player::processKeep(): invalid DecisionRecord (null bet).");
        return;
    }

    // Confirm we actually own the bet in dr.pBet (raw pointer)
    // Obtain shared_ptr to our bet
    //
    auto pBet = findBetById(dr.pBet->betId());
    if (pBet == nullptr)
    {
        diagBadBetId("processKeep() ", dr.pBet->betId());
        assert(false);
        return;
    }

    assert(dr.lose == 0); assert(dr.win == 0);
    currentStats_.recordKeep(*(dr.pBet));
}

/*-----------------------------------------------------------*//**

CrapsTable informs us directly (inline) that it is finished resolving
bets. Can't use events for this since bets will have already have been
removed by the time we see those events here.

Close out lastRollStats (no need to do that here as it is cleared in
betting closed) and publish events.  Always send the event. Doesn't
matter if no bets had a decision.  Want last roll stats to show +$0
change on screen.
*/
void
Player::disburseDone()
{
    // A settled bet can have zero net money movement. World is an example:
    // on a 7, its winning component's profit offsets the four losing
    // components. Still publish the changed bet/statistics state so the CUI
    // does not remain stale until another roll with non-zero money movement.
    if (lastRollStats_.numBetsWin > 0 || lastRollStats_.numBetsLose > 0)
    {
        sendEventPlayerBetsChanged();
        sendEventPlayerSessionStatsChanged();
        sendEventPlayerBalanceChanged();
    }
    sendEventPlayerLastRollStatsChanged();
}

//----------------------------------------------------------------

BetPtr
Player::getBet(const BetId& betId, Gen::ErrorPass& ep) const
{
    auto b = findBetById(betId);
    if (b != nullptr) return b;

    ep.setDescription("Player::getBet(): player " + playerName_ +
                      " has no such betId " + std::to_string(betId) + ".");
    return nullptr;
}

//----------------------------------------------------------------

Craps::BetId
Player::getBet(BetName betName, size_t pivot, Gen::ErrorPass& ep) const
{
    auto it = std::find_if(bets_.begin(), bets_.end(),
                   [betName, pivot](const BetPtr& b)
                   {
                       return b->betName() == betName &&
                              b->pivot()   == pivot;
                   });
    if (it != bets_.end())
    {
        return (*it)->betId();
    }
    return 0;
}

//----------------------------------------------------------------

Player::Bets
Player::getBets() const
{
    std::vector<BetPtr> returnBets;
    for (auto b : bets_)
    {
        returnBets.push_back(b);
    }
    return returnBets;
}

//----------------------------------------------------------------
//
// Return bets capable of odds
//
Player::Bets
Player::getOddsBets() const
{
    std::vector<BetPtr> returnBets;
    for (auto b : bets_)
    {
        if ((b->betName() == BetName::PassLine  ||
             b->betName() == BetName::Come      ||
             b->betName() == BetName::DontPass  ||
             b->betName() == BetName::DontCome) &&
            (b->pivot() != 0))
        {
            returnBets.push_back(b);
        }
    }
    return returnBets;
}

//----------------------------------------------------------------

bool
Player::haveBet(const BetId& betId) const
{
    return findBetById(betId) != nullptr;
}

//----------------------------------------------------------------

bool
Player::haveAnyOddsCapableBet() const
{
    for (auto b : bets_)
    {
        if ((b->betName() == BetName::PassLine  ||
             b->betName() == BetName::Come      ||
             b->betName() == BetName::DontPass  ||
             b->betName() == BetName::DontCome) &&
            (b->pivot() != 0))
        {
            return true;
        }
    }
    return false;
}

//----------------------------------------------------------------
//
// Search for bet by ID
//
BetPtr
Player::findBetById(const BetId& betId) const
{
    auto it = std::find_if(bets_.begin(), bets_.end(),
                   [betId](const BetPtr& b)
                   {
                       return b->betId() == betId;
                   });
    if (it != bets_.end())
    {
        return *it;
    }
    return nullptr;
}

//----------------------------------------------------------------
//
// Private function. Used to remove a bet from this player's
// collection. Meant to be called after processing a bet result.
//
bool
Player::removeBetByPtr(BetPtr& b)
{
    auto it = std::find(bets_.begin(), bets_.end(), b);
    if (it != bets_.end())
    {
        bets_.erase(it);
        return true;
    }
    return false;
}

//----------------------------------------------------------------
//
// Remove bet by betId.
//
// Called by the UI to remove a bet from the table.
//
zeus::expected<void, Gen::ErrorPass>
Player::removeBet(const BetId& betId)
{
    Gen::ErrorPass ep;

    auto it = std::remove_if(bets_.begin(), bets_.end(),
        [betId](const BetPtr& b)
        {
            return (b->betId() == betId);
        });
    if (it == bets_.end())
    {
        std::string s = fmt::format("Unable to remove bet; Player {} "
                                    "does not have a bet with betId:{}.",
                                    playerName_,  betId);
        EP_SET(ep, En::NotFoundError, Et::ProcessingError, Es::Indeterminate, s);
        return zeus::unexpected(std::move(ep));
    }

    // We have a bet, then we must have valid pTable. No need to check.
    // We have a bet, then it must be on the table. See makeBet().
    // If table can't remove it then player can't remove it.
    if (pTable_->removeBet(*it, ep) == Gen::ReturnCode::Fail)
    {
        return zeus::unexpected(std::move(ep));
    }

    const Gen::Money placementFee = (*it)->hasDecision()
        ? 0 : (*it)->placementCommission();
    if (placementFee > 0)
        pTable_->refundPlacementCommission(*(*it));
    wallet_.deposit((*it)->contractAmount() + (*it)->oddsAmount() + placementFee);
    bets_.erase(it, bets_.end());  // remove from our list of bets

    sendEventPlayerBetsChanged();
    sendEventPlayerBalanceChanged();

    return {};
}

//----------------------------------------------------------------

void
Player::resetStats()
{
    currentStats_.reset();
    wallet_.resetStats();
}

//----------------------------------------------------------------
//
// Returns the amount of money currently bet on the table.
//
unsigned
Player::getAmountOnTable() const
{
    unsigned amount = 0;
    for (auto& b : bets_)
    {
        amount += b->contractAmount() + b->oddsAmount();
    }
    return amount;
}

//----------------------------------------------------------------
//
// Returns number of bets currently on the table.
//
unsigned
Player::getNumBetsOnTable() const
{
    return bets_.size();
}

//----------------------------------------------------------------

const PlayerId&
Player::getPlayerId() const
{
    return playerId_;
}

//----------------------------------------------------------------

const std::string&
Player::getName() const
{
    return playerName_;
}

//----------------------------------------------------------------

void
Player::setName(const std::string& playerName)
{
    playerName_ = playerName;
}

//----------------------------------------------------------------

Gen::Money
Player::getBalance() const
{
    return wallet_.getBalance();
}

//----------------------------------------------------------------

int
Player::getSessionNet() const
{
    return wallet_.getSessionNet();
}

/*-----------------------------------------------------------*//**

Returns read-only access to current session player stats.

@return current session player stats (read-only)

*/
const PlayerStats&
Player::getCurrentStats() const
{
    return currentStats_;
}

/*-----------------------------------------------------------*//**

Returns read-only access to all-time stats.

All-time stats are an aggregation of all sessions for this player.

Note that all-time stats are only updated when the current session ends.

@return all-time table stats (read-only)

*/
const PlayerStats&
Player::getAlltimeStats() const
{
    return alltimeStats_;
}

//----------------------------------------------------------------

const BankStats&
Player::getBankCurrentStats() const
{
    return wallet_.getCurrentStats();
}

//----------------------------------------------------------------

const BankStats&
Player::getBankAlltimeStats() const
{
    return wallet_.getAlltimeStats();
}

//----------------------------------------------------------------

const LastRollStats&
Player::getLastRollStats() const
{
//    if (pTable_ != nullptr)
//    {
        lastRollStats_.rollCount = pTable_->getNumRolls();
//    }
    return lastRollStats_;
}

//----------------------------------------------------------------
//
// Return session history.
//
// This is just a relay function for convenience.
//
const SessionHistory::Sessions&
Player::getSessionHistory() const
{
    return alltimeStats_.sessionHistory.getSessions();
}

//----------------------------------------------------------------

void
Player::diagBadBetId(const std::string& funcName, BetId betId) const
{
    std::string diag =
        "Internal Error: Unable to process decision record. "
        "Player::" + funcName + "cant match "
        "decision record betId against any betId held "
        "in player betList. Bad betId:" + std::to_string(betId);
    LOG_ERROR(diag); 
}

//----------------------------------------------------------------

std::string
Player::diagPrefix(size_t idx) const
{
    assert(idx == 1 || idx == 2);
    std::string diag("Player::");
    if (idx == 1)
    {
        diag += "makeBet(): Player:" + playerName_  + "; Unable to make bet; ";
    }
    if (idx == 2)
    {
        diag += "setOdds(): Player:" + playerName_  + "; Unable to set odds; ";
    }
    return diag;
}

//----------------------------------------------------------------

void
Player::sendEventBetResolved(BetName betName,
                             BetId betId,
                             const DecisionRecord& dr) const
{
    Ctrl::UslBetResolved ev;
    ev.playerId       = playerId_,
    ev.betName        = betName,
    ev.betId          = betId,
    ev.amountWin      = dr.win;
    ev.amountLose     = dr.lose;
    ev.returnToPlayer = dr.returnToPlayer;
    ev.commission      = dr.commission;

    Gen::EventManager::instance().publish(ev);
}

//----------------------------------------------------------------

void
Player::sendEventPlayerBetsChanged() const
{
    Ctrl::UslPlayerBetsChanged ev;
    ev.playerId       = playerId_;
    ev.numBetsOnTable = getNumBetsOnTable();
    ev.amountOnTable  = getAmountOnTable();

    Gen::EventManager::instance().publish(ev);
}

//----------------------------------------------------------------

void
Player::sendEventPlayerSessionStatsChanged() const
{
    Ctrl::UslPlayerSessionStatsChanged ev;
    ev.playerId    = playerId_;
    ev.numBetsWon  = currentStats_.betStats.totNumWinsAllBets;
    ev.numBetsLost = currentStats_.betStats.totNumLoseAllBets;

    Gen::EventManager::instance().publish(ev);
}

//----------------------------------------------------------------

void        
Player::sendEventPlayerLastRollStatsChanged() const
{
    Ctrl::UslPlayerLastRollStatsChanged lrs{};
    lrs.playerId = playerId_;
    lrs.stats    = lastRollStats_;
    Gen::EventManager::instance().publish(lrs);
}

//----------------------------------------------------------------

void
Player::sendEventPlayerBalanceChanged() const
{
    Ctrl::UslPlayerBalanceChanged ev;
    ev.playerId   = playerId_;
    ev.balance    = getBalance();    // how much left in wallet
    ev.netBalance = getSessionNet(); // profilt/loss session start

    Gen::EventManager::instance().publish(ev);
}

//----------------------------------------------------------------

bool
Player::fifNoTable(Gen::ErrorPass& ep) const
{
    // fault if player is not joined to a table and sets ep error diag
    if (pTable_ == nullptr)
    {
        std::string s("Player " + playerName_ + " has not yet joined a table.");
        EP_SET(ep, En::InvalidAccessError, Et::ProcessingError,
               Es::Indeterminate, s);
        return true;
    }
    return false;
}

//----------------------------------------------------------------

bool
Player::fifInsufficientFunds(BetPtr pBet, Gen::Money newAmount,
                             Gen::Money oldAmount,
                             Gen::ErrorPass& ep) const
{
    // fault if insufficient funds and sets ep error diag

    // nullptr arg is expected when called from makeBet(), since a
    // bet has not yet been created.

    int diff = 0;
    if (pBet == nullptr)
    {
        diff = newAmount;
    }
    else
    {
        diff = newAmount - oldAmount;
    }

    if (diff <= 0)
    {
        return false;  // Reducing existing bet, always enough funds.
    }

    if (diff > wallet_.getBalance())
    {
        std::string s = fmt::format(
            "Player {} has insufficient funds to make a {} bet; "
            "current balance:{}.", playerName_,
            Gen::MoneyUtils::toString(newAmount),
            Gen::MoneyUtils::toString(getBalance()));
        EP_SET(ep, En::UnderflowError, Et::ProcessingError,
               Es::Indeterminate, s);
        return true;
    }
    return false;
}

//----------------------------------------------------------------

bool
Player::fifBadAddBet(BetPtr pBet, Gen::ErrorPass& ep) const
{
    // fault if can't add bet and sets ep error diag
    assert(pBet != nullptr);
    assert(pTable_ != nullptr);

    if (pTable_->addBet(pBet, ep) == Gen::ReturnCode::Fail)
    {
        return true;
    }
    return false;
}

//----------------------------------------------------------------

bool
Player::fifMissingBet(BetPtr pBet, Gen::ErrorPass& ep) const
{
    // fault if bet is not owned by this player and sets ep error diag

    if (pBet == nullptr)
    {
        EP_SET(ep, En::NullPointerError, Et::ProcessingError,
               Es::Indeterminate, diagPrefix(2) + "BetPtr is null.");
        return true;
    }
    
    if (findBetById(pBet->betId()) == nullptr)
    {
        if (pBet->player().getPlayerId() == playerId_)
        {
            // Bet was somehow created outside of makeBet()
            std::string s = fmt::format(
                "{} Player:{} does not have this bet in their bet list; "
                "Programmer error; Must use Player::makeBet() to make "
                "a bet; {}.", diagPrefix(2), playerName_, pBet->diagBetId());
            EP_SET(ep, En::LogicError, Et::ProcessingError,
                   Es::Indeterminate, s);
            return true;
        }
        std::string s = fmt::format(
            "{} Player:{} does not own this bet {}; Owned by Player:{}.",
            diagPrefix(2), playerName_,
            pBet->diagBetId(), pBet->player().getName());
        EP_SET(ep, En::InvalidAccessError, Et::ProcessingError,
               Es::Indeterminate, s);
        return true;
    }
    return false;
}

//----------------------------------------------------------------
