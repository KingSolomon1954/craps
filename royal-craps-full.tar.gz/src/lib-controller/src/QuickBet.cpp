//----------------------------------------------------------------
//
// File: QuickBet.cpp
//
//----------------------------------------------------------------

#include <controller/QuickBet.h>
#include <controller/BetEntryYaml.h>
#include <algorithm>

using namespace Ctrl;

//----------------------------------------------------------------

void
QuickBet::applyQuickBet(size_t index)
{
#if 0
    Gen::ErrorPass ep;
    Craps::BetId betId;
    Gen::ReturnCode rc;
    
    auto* pPlayer = Gbl::pPlayerMgr->getUserPlayer();
    assert(pPlayer != nullptr);
    
    if (index >= bets_.size()) return;  // probably should assert()
    auto& qbe = bets_[index];
    if (qbe.isOddsBet)
    {
        betId = pPlayer->getBet(qbe.betName, qbe.pivot, ep);
        if (betId == 0)
        {
            // TODO handle error
        }
        // Go through CrapsCommands so bet is logged and undoable.
        auto correlationId = CrapsCommands::cmdBetSetOddsAmount(
            betId,
            qbe.amount);
            // TODO
            // pOwning_->onBetFailed(playerId, ep.diag);
            // showDialogAckError(ep.diag);
    }
    else
    {
        // Go through CrapsInterface so bet is logged and undoable.
        auto correlationId = CrapsCommands::cmdMakeBet(
            pPlayer->getPlayerId(),
            qbe.betName,
            qbe.amount,
            qbe.pivot);

            // TODO
            // pOwning_->onBetFailed(playerId, ep.diag);
            // showDialogAckError(ep.diag);
    }
#endif    
}

//----------------------------------------------------------------

void
QuickBet::setQuickBet(const QuickBetEntry& qbe)
{
    // Look for an existing entry with same betName, pivot, and isOddsBet
    auto it = std::find_if(bets_.begin(), bets_.end(),
        [&](const QuickBetEntry& existing) {
            return existing.betName   == qbe.betName
                && existing.pivot     == qbe.pivot
                && existing.isOddsBet == qbe.isOddsBet;
        });

    if (it != bets_.end())
    {
        it->amount = qbe.amount;  // Replace amount only
    }
    else
    {
        bets_.push_back(qbe);    // No match: add new entry
    }
}

//----------------------------------------------------------------

void
QuickBet::deleteQuickBet(const QuickBetEntry& qbe)
{
    auto it = std::find_if(bets_.begin(), bets_.end(),
        [&](const QuickBetEntry& existing) {
            return existing.betName   == qbe.betName
                && existing.pivot     == qbe.pivot
                && existing.isOddsBet == qbe.isOddsBet;
        });

    if (it != bets_.end())
    {
        // Erase compacts the vector automatically (no "holes")
        bets_.erase(it);
    }
}

//----------------------------------------------------------------

void
QuickBet::deleteQuickBet(size_t index)
{
    if (index < bets_.size())
    {
        bets_.erase(bets_.begin() + index);
    }
}

//----------------------------------------------------------------

const QuickBet::QuickBets&
QuickBet::getQuickBets()
{
    return bets_;
}

//----------------------------------------------------------------

void
QuickBet::clear()
{
    bets_.clear();
}

//----------------------------------------------------------------
//
// Entries as a YAML sequence, in order. Order matters; quick bets
// are applied and deleted by index.
//
YAML::Node
QuickBet::toYAML() const
{
    return betEntriesToYAML(bets_);
}

//----------------------------------------------------------------
//
// Replaces current entries with those in the YAML sequence. Never
// throws. Anything unusable is logged and skipped.
//
void
QuickBet::fromYAML(const YAML::Node& node)
{
    bets_.clear();
    betEntriesFromYAML<QuickBetEntry>(node, "QuickBet::fromYAML(): ",
        [this](const QuickBetEntry& e) { setQuickBet(e); });  // collapses dups
}

//----------------------------------------------------------------
