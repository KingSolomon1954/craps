//----------------------------------------------------------------
//
// File: WindowPlayerBrief.cpp
//
//----------------------------------------------------------------

#include <cui/panels/WindowPlayerBrief.h>
#include <cui/core/CuiUtils.h>
#include <cui/core/CuiStructs.h>
#include <cui/layouts/LayoutCrapsScreen.h>
#include <cui/managers/ColorManager.h>
#include <gen/ErrorPass.h>
#include <gen/Logger.h>
#include <iomanip>
#include <sstream>
#include <string>

using namespace Cui;

//----------------------------------------------------------------

WindowPlayerBrief::WindowPlayerBrief()
    : PanelBase("WindowPlayerBrief")
{
    newWindow(Layout::playerBriefHeight,           // In base class
              Layout::playerBriefWidth,
              Layout::playerBriefTopRow,
              Layout::playerBriefLeftCol);
    initPlayer();
}

//----------------------------------------------------------------

WindowPlayerBrief&
WindowPlayerBrief::instance()
{
    static WindowPlayerBrief hb;
    return hb;
}

//----------------------------------------------------------------

void
WindowPlayerBrief::initPlayer()
{
    Gen::ErrorPass ep;
    auto rc = Ctrl::CrapsReaders::getUserPlayer(playerId_, ep);
    assert(rc == Gen::ReturnCode::Success);
    
    playerName_ = Ctrl::CrapsReaders::getUserPlayerName();
    (void) Ctrl::CrapsReaders::readPlayerBalance(playerId_, balance_, ep);
}

//----------------------------------------------------------------
//
//  ┬─────────────────────────────┐
//  │ Player: Nathan (shooter)    │
//  │ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ │
//  │ Bal: $2,000 Net: +$1,044    │
//  │ NumBets: 55 (21W, 34L)      │
//  │ Pct: 38.18% win 61.81% lose │
//  │ Last: 180W,100L,+$80,       │
//  │ On table: 3 bets, $320      │
//  ├─────────────────────────────┤
//
void
WindowPlayerBrief::draw()
{
    werase(pWin_);

    drawExternalJunctions();
    drawInternalBorders();
    drawStaticContent();
    populate();
    
    CuiUtils::transfer(pWin_);
}

//----------------------------------------------------------------
//
// We need to touch up border junctions to mate with our internal
// lines. But the border is outside of our window. Ask LayoutCrapsTable
// to take of it.
//
void
WindowPlayerBrief::drawExternalJunctions()
{
    // Have none
}

//----------------------------------------------------------------

void
WindowPlayerBrief::drawInternalBorders()
{
    std::string s(" ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~");
    mvwaddstr(pWin_, 1, 0, s.c_str());
}

//----------------------------------------------------------------
//
// Draw static field contents
//
void
WindowPlayerBrief::drawStaticContent()
{
    // Have none
}

//----------------------------------------------------------------
//
// Updates all dynamic field content.
//
void
WindowPlayerBrief::populate()
{
    populateName();
    populateBalance();
    populateNumBets();
    populatePct();
    populateOnTable();
    populateLast();
}

//----------------------------------------------------------------

void
WindowPlayerBrief::populateName()
{
    std::string n = playerName_;
    n += shooter_;

    PlayerColor pc = PlayerColor::One;
    const auto pColor = ColorManager::instance().getPlayerColor(playerId_);
    assert(pColor.has_value());
    if (pColor.has_value())
    {
        pc = *pColor;
    }
    
    wattron(pWin_, COLOR_PAIR(ColorManager::instance().pair(pc)));
    mvwaddstr(pWin_, 0, 1, n.c_str());
    wattroff(pWin_, COLOR_PAIR(ColorManager::instance().pair(pc)));
}

//----------------------------------------------------------------

void
WindowPlayerBrief::populateBalance()
{
    //  │ Bal: $2,000 Net: +$8,280       │

    int positiveNum = netBalance_;
    
    std::string plusOrMinus("+");
    if (netBalance_ < 0)
    {
        positiveNum = -netBalance_;
        plusOrMinus = "-";
    }

    std::string s = "Bal: " + Gen::MoneyUtils::toString(balance_);
    s += " (" + plusOrMinus + Gen::MoneyUtils::toString(
                              static_cast<unsigned>(positiveNum));
    s += ")";

    mvwaddstr(pWin_, 2, 1, s.c_str());
}

//----------------------------------------------------------------

void
WindowPlayerBrief::populateNumBets()
{
    std::string s = "NumBets: ";
    s += std::to_string(numBetsPlayerWins_ + numBetsPlayerLoses_) + " ";
    s += std::to_string(numBetsPlayerWins_)  + "W,";
    s += std::to_string(numBetsPlayerLoses_) + "L";
    
    mvwaddstr(pWin_, 3, 1, s.c_str());
}

//----------------------------------------------------------------

void
WindowPlayerBrief::populatePct()
{
    std::string s = playerWinPercentages();
    mvwaddstr(pWin_, 4, 1, s.c_str());
}

//----------------------------------------------------------------

std::string
WindowPlayerBrief::playerWinPercentages() const
{
    const unsigned total = numBetsPlayerWins_ + numBetsPlayerLoses_;

    if (total == 0)
    {
        return "Pct: 0.00% win 0.00% lose";
    }

    const double winPercent =
        100.0 * static_cast<double>(numBetsPlayerWins_) / total;

    const double losePercent =
        100.0 * static_cast<double>(numBetsPlayerLoses_) / total;

    std::ostringstream out;
    out << "Pct: "
        << std::fixed << std::setprecision(2)
        << winPercent << "% win "
        << losePercent << "% lose";

    return out.str();
}

//----------------------------------------------------------------

void
WindowPlayerBrief::populateLast()
{
    std::string s = "Last: ";
    std::string plusOrMinus("+");
    
    int total = playerIntakeLastRoll_ - playerOutputLastRoll_;
    
    if (total < 0)
    {
        plusOrMinus = "-";
        total = -total;    // avoid to_string() adding its own "-"
    }

    s += plusOrMinus + "$" + std::to_string(total) + " ";
    s += std::to_string(playerIntakeLastRoll_) + "W,";
    s += std::to_string(playerOutputLastRoll_) + "L";

    mvwaddstr(pWin_, 5, 1, s.c_str());
}

//----------------------------------------------------------------

void
WindowPlayerBrief::populateOnTable()
{
    std::string               b = " bets, ";
    if (numBetsOnTable_ == 1) b = " bet, ";
    
    std::string s = "On table: ";
    s += std::to_string(numBetsOnTable_) + b;
    s += Gen::MoneyUtils::toString(amtOnTable_);

    mvwaddstr(pWin_, 6, 1, s.c_str());
}

//----------------------------------------------------------------

void
WindowPlayerBrief::onResolveBetsEnd()
{
    // Empty
}

//----------------------------------------------------------------

void
WindowPlayerBrief::onNewShooter(const Craps::PlayerId& playerId)
{
    if (playerId == playerId_)
    {
        shooter_ = " (shooter)";
    }
    else
    {
        shooter_.clear();
    }
}

//----------------------------------------------------------------

void
WindowPlayerBrief::onPlayerBetsChanged(
    const Craps::PlayerId& playerId,
    unsigned numBetsOnTable,
    Gen::Money amountOnTable)
{
    if (playerId != playerId_) return;

    numBetsOnTable_ = numBetsOnTable;
    amtOnTable_     = amountOnTable;
}

//----------------------------------------------------------------

void
WindowPlayerBrief::onPlayerSessionStatsChanged(
    const Craps::PlayerId& playerId,
    unsigned numBetsWon,
    unsigned numBetsLost)
{
    if (playerId != playerId_) return;

    numBetsPlayerWins_  = numBetsWon;
    numBetsPlayerLoses_ = numBetsLost;
}

//----------------------------------------------------------------

void
WindowPlayerBrief::onPlayerLastRollStatsChanged(
    const Craps::PlayerId& playerId,
    const Craps::LastRollStats& lrs)
{
    if (playerId != playerId_) return;

    playerIntakeLastRoll_ = lrs.amountWin;
    playerOutputLastRoll_ = lrs.amountLose;
}

//----------------------------------------------------------------

void
WindowPlayerBrief::onPlayerBalanceChanged(
    const Craps::PlayerId& playerId,
    Gen::Money             balance,     // how much left in wallet
    int                    netBalance)  // profit/loss this session
{
    if (playerId != playerId_) return;
    
    balance_    = balance;    
    netBalance_ = netBalance;
}

//----------------------------------------------------------------
